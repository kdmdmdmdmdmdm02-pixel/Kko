# ZAQERIS M3-GPTQ (`M3 - GPTQ`) — Complete Reproducibility, Research & Release Archive

مرحبًا بك في الأرشيف الكامل والمكتفي ذاتياً لتقنية الضغط **ZAQERIS M3-GPTQ**، والذي يضم كود الحزمة المصدري، والاختبارات، ومرجع كيرنل `NVRTC CUDA Graph`، وجميع ملفات النتائج الخام، والورقة العلمية، والتقارير المقارنة، وحزمة النشر.

## هيكل المجلدات (`Directory Structure`)

| المجلد | الغرض والمحتوى |
| :--- | :--- |
| **`01_Results/`** | جميع ملفات النتائج الخام (JSON) المشار إليها في الورقة والتقارير: تجارب `1.5B` (`results_m3_proof.json`, `results_m3_gptq.json`, `qwen2.5_coder_1.5b_full_comparison.json`, `pareto`, `baselines`, `paired_wikitext2`), `e2e_pipeline` (`results_e2e_pipeline_proof.json`), `qwen2.5_coder_7b_comparison.json`, `mistral_7b_comparison.json`, و`zqn12b_paired_comparison.json`. |
| **`02_Models_Tested/`** | بطاقات النماذج المختبَرة ومواصفاتها المعمارية، إعدادات التكميم، وأحجام الأوزان قبل وبعد الضغط (`MODELS_MANIFEST.md`). |
| **`03_Technical_Papers/`** | الورقة العلمية المدقّقة النهائية (`ZAQERIS_M3_GPTQ_PAPER.md`) وملف الشرح التقني (`ZAQERIS_M3_GPTQ_TECHNICAL_EXPLANATION.md`). |
| **`04_Reports_and_Reviews/`** | 1) تدقيق تجارب النموذج الأول، 2) تقرير البنشمارك والإعدادات النهائي الموحّد، 3) التدقيق الهندسي النقدي الداخلي والقيود (`03_INTERNAL_ENGINEERING_AND_LIMITATIONS_AUDIT.md`). |
| **`05_Press_Kit_and_Social/`** | حزمة الـ Press Kit والمنشورات الجاهزة (`PRESS_KIT_AND_ANNOUNCEMENTS.md`) مع فصل واضح بين سرعة `M3Linear` العامة وسرعة `NVRTC` المخصصة لـ `ZQN-12B`. |
| **`06_Code_and_Benchmarks/`** | الحزمة المصدرية الكاملة [`zaqeris-m3-gptq/`](./06_Code_and_Benchmarks/zaqeris-m3-gptq/) (`zaqeris_m3_gptq/` + `tests/` + `pyproject.toml` + `LICENSE`) + مرجع كيرنل [`nvrtc_kernel_reference/`](./06_Code_and_Benchmarks/nvrtc_kernel_reference/) + سكربتات إعادة الإنتاج (`reproduce_m3_benchmarks.py`, `run_7b_m3_suite.py`, `run_quant_comparison.py`, `exp_e2e_pipeline_proof.py`). |

---

## أوزان النماذج وبيانات التقييم (`Model Weights & Datasets — Not Bundled`)

- **لم يتم تضمين أوزان النماذج أو ملفات البيانات الضخمة داخل هذا الأرشيف** حتى يظل الأرشيف خفيفاً وقابلاً للنقل بسهولة.
- يمكن لأي باحث أو مطور تحميل النماذج والبيانات مباشرةً من Hugging Face عند التشغيل المحلي:
  - **النماذج:** `Qwen/Qwen2.5-Coder-1.5B`، `Qwen/Qwen2.5-Coder-7B-Instruct`، `mistralai/Mistral-7B-Instruct-v0.3`، `ZAQERIS/ZQN-12B`.
  - **البيانات:** `Salesforce/wikitext` (`wikitext-2-raw-v1`)، `cais/mmlu`، `allenai/ai2_arc`.
- السكربتات المرفقة في `06_Code_and_Benchmarks/` (مثل `run_quant_comparison.py` و`run_7b_m3_suite.py`) تقوم بتحميل النماذج والبيانات تلقائياً عبر `transformers` و`datasets` بمجرد تمرير اسم النموذج (`--model <HF_MODEL_ID>`).
- **ملاحظة حول `exp_e2e_pipeline_proof.py`:** مرفق كمرجع لتجربة `Merge -> Gauge Rotation -> M3-GPTQ` على `28` طبقة، ويتطلب نقاط تفتيش (`checkpoints`) ومدونة نصوص محلية (`corpus_dir`) خاصة بتلك التجربة.

---

> **ملاحظة الفصل بين بيئات التشغيل والسرعة والذاكرة:**
> - الحزمة العامة `zaqeris-m3-gptq` (`M3Linear`) تعتمد حالياً على مسار فك ضغط مرجعي في PyTorch (`0.19–1.53 tok/s`)، بينما سرعة `22.94 tok/s` الموثقة لـ `ZQN-12B` تعود إلى كيرنل `NVRTC LUT + Static CUDA Graph` المخصص والمرفق كمرجع في `06_Code_and_Benchmarks/nvrtc_kernel_reference/`.
> - على `ZQN-12B`: الذاكرة المحمّلة للأوزان (`Loaded VRAM`) هي `6.046 GiB` بينما ذروة التقييم (`Eval Peak VRAM` شاملةً التنشيطات وKV cache) تصل إلى `7.522 GiB` (متجاوزةً ميزانية WDDM الفيزيائية `~6.87 GiB` بمقدار ~`0.65 GiB` عبر الذاكرة المشتركة، في حين أن أوزان `4-bit NF4` وحدها تبلغ `~8.8 GiB` قبل التنشيطات).
> - الرخصة: **Apache-2.0** (مرفقة في [`LICENSE`](./LICENSE) و[`zaqeris-m3-gptq/LICENSE`](./06_Code_and_Benchmarks/zaqeris-m3-gptq/LICENSE)).
