"""Unit and integration tests for ZAQERIS M3-GPTQ public release."""

from __future__ import annotations

import math
import re
from pathlib import Path

import pytest
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, Qwen2Config

from zaqeris_m3_gptq import (
    M3Config,
    M3Linear,
    compress_causal_lm,
    dequantize_m3_weight,
    get_cache,
    load_m3_layer,
    load_m3_model,
    m3_gptq_quantize,
    make_hadamard_block,
    pack_indices,
    quantize_linear_layer,
    reset_cache,
    save_m3_layer,
    save_m3_model,
    unpack_indices,
)
from zaqeris_m3_gptq.cli import build_parser

PACKAGE_ROOT = Path(__file__).resolve().parents[1]


def _make_correlated_problem(m: int = 256, n: int = 256, seed: int = 42):
    gen = torch.Generator().manual_seed(seed)
    w = torch.randn(m, n, generator=gen) * 0.05
    u = torch.randn(m, 16, generator=gen)
    v = torch.randn(16, n, generator=gen)
    w = w + 0.08 * (u @ v)
    w[0, min(3, n - 1)] = 1.8
    w[min(17, m - 1), min(129, n - 1)] = -1.6
    x = torch.randn(512, n, generator=gen)
    h = (x.t() @ x) / x.shape[0]
    return w, h, x


@pytest.mark.parametrize("bits", [4, 5, 6, 7, 8])
@pytest.mark.parametrize("length", [17, 255, 1024, 4099])
def test_pack_unpack_roundtrip(bits: int, length: int) -> None:
    gen = torch.Generator().manual_seed(100 + bits + length)
    idx = torch.randint(0, 1 << bits, (3, length), generator=gen, dtype=torch.int64)
    packed = pack_indices(idx, bits=bits)
    expected_bytes = (length * bits + 7) // 8
    assert packed.dtype == torch.uint8
    assert packed.shape == (3, expected_bytes)
    unpacked = unpack_indices(packed, num_elements=length, bits=bits)
    assert torch.equal(idx, unpacked)


@pytest.mark.parametrize(
    ("preset", "expected_bpw_range"),
    [
        ("3x8b", (3.2, 3.45)),
        ("3x8b_tight", (3.05, 3.30)),
        ("3x7b", (2.68, 2.85)),
        ("4x5b", (2.55, 2.75)),
        ("3x6b", (2.30, 2.48)),
        ("2x8b", (2.05, 2.25)),
    ],
)
def test_m3_gptq_presets_and_dequant_parity(
    preset: str, expected_bpw_range: tuple[float, float]
) -> None:
    # Use 1024x1024 so codebook overhead reflects realistic layer dimensions
    w, h, _ = _make_correlated_problem(m=1024, n=1024, seed=7)
    cfg = M3Config.from_preset(preset)
    r_g = make_hadamard_block(block_dim=cfg.group_size, seed=cfg.hadamard_seed, device="cpu")
    res = m3_gptq_quantize(
        w_in=w,
        h_in=h,
        r_g=r_g,
        name=f"test_{preset}",
        outlier_ratio=cfg.outlier_ratio,
        stages=cfg.stages,
        cb_size=cfg.cb_size,
        damp=cfg.damp,
        vec_dim=cfg.vec_dim,
        kmeans_iters=cfg.kmeans_iters,
        hadamard_seed=cfg.hadamard_seed,
    )
    assert res.w_hat is not None
    assert expected_bpw_range[0] <= res.effective_bpw <= expected_bpw_range[1]
    assert res.cosine > 0.84
    assert res.rel_l2 < 0.55

    reconstructed = dequantize_m3_weight(res, device="cpu", dtype=torch.float32, r_g=r_g)
    max_diff = (reconstructed - res.w_hat).abs().max().item()
    assert max_diff < 1e-4


def test_save_and_load_m3_layer_roundtrip(tmp_path: Path) -> None:
    w, h, _ = _make_correlated_problem(m=256, n=256, seed=11)
    res = m3_gptq_quantize(w, h, stages=3, cb_size=128, outlier_ratio=0.0025)
    layer_path = tmp_path / "proj.safetensors"
    save_m3_layer(res, layer_path)
    loaded = load_m3_layer(layer_path, reconstruct=True)

    assert loaded.shape == res.shape
    assert loaded.stages == res.stages
    assert loaded.cb_size == res.cb_size
    assert loaded.storage_bytes == res.storage_bytes
    assert torch.equal(loaded.packed_indices, res.packed_indices)
    assert torch.equal(loaded.outlier_coords, res.outlier_coords)
    assert torch.equal(loaded.outlier_vals, res.outlier_vals)
    assert loaded.w_hat is not None and res.w_hat is not None
    assert (loaded.w_hat - res.w_hat).abs().max().item() < 1e-5


@pytest.mark.parametrize("dtype", [torch.float16, torch.bfloat16, torch.float32])
def test_m3_linear_forward_parity_and_cache(dtype: torch.dtype) -> None:
    reset_cache(budget_mib=16.0, max_entry_mib=8.0)
    w, h, x = _make_correlated_problem(m=256, n=256, seed=21)
    linear = nn.Linear(256, 256, bias=True)
    with torch.no_grad():
        linear.weight.copy_(w)
        linear.bias.copy_(torch.randn(256))

    cfg = M3Config.from_preset("3x7b")
    res, m3_lin = quantize_linear_layer(linear, h, config=cfg, name="fc", use_cache=True)
    assert res.w_hat is not None

    x_in = x[:4].to(dtype)
    y_m3_first = m3_lin(x_in)
    y_m3_cached = m3_lin(x_in)
    assert torch.equal(y_m3_first, y_m3_cached)

    stats = get_cache().snapshot()
    assert stats["stores"] >= 1
    assert stats["hits"] >= 1

    w_ref = res.w_hat.to(dtype)
    b_ref = linear.bias.to(dtype)
    y_ref = F.linear(x_in, w_ref, b_ref)
    tol = 5e-2 if dtype == torch.bfloat16 else 2e-2
    assert (y_m3_first - y_ref).abs().max().item() < tol


def test_m3_linear_chunked_forward_parity(monkeypatch: pytest.MonkeyPatch) -> None:
    import zaqeris_m3_gptq.runtime as rt

    monkeypatch.setattr(rt, "_CHUNK_ROWS", 64)
    reset_cache(budget_mib=0.0, max_entry_mib=0.0)
    w, h, x = _make_correlated_problem(m=192, n=128, seed=33)
    linear = nn.Linear(128, 192, bias=True)
    with torch.no_grad():
        linear.weight.copy_(w)
    res, m3_lin = quantize_linear_layer(
        linear, h, config=M3Config.from_preset("3x7b"), name="chunked", use_cache=False
    )
    assert res.w_hat is not None
    y_chunked = m3_lin(x[:3].float())
    y_ref = F.linear(x[:3].float(), res.w_hat.float(), linear.bias.float())
    assert (y_chunked - y_ref).abs().max().item() < 1e-4


def test_compress_save_and_load_causal_lm(tmp_path: Path) -> None:
    reset_cache(budget_mib=64.0, max_entry_mib=16.0)
    hf_cfg = Qwen2Config(
        vocab_size=512,
        hidden_size=128,
        intermediate_size=256,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
    )
    model = AutoModelForCausalLM.from_config(hf_cfg).eval()
    calib = torch.randint(0, 512, (4, 32), dtype=torch.long)

    m3_cfg = M3Config.from_preset("3x7b")
    stats = compress_causal_lm(
        model=model,
        calib_tokens=calib,
        config=m3_cfg,
        replace_modules=True,
        use_cache=True,
        device="cpu",
    )
    assert stats["num_layers"] == 14
    expected_bpw = stats["total_storage_bytes"] * 8.0 / stats["total_params"]
    assert math.isclose(stats["effective_bpw"], expected_bpw, rel_tol=1e-9)
    assert stats["effective_bpw"] < 6.0
    assert stats["mean_cosine"] > 0.85
    assert any(isinstance(m, M3Linear) for m in model.modules())

    out_dir = tmp_path / "compressed_qwen2"
    save_m3_model(model, out_dir, config=m3_cfg)
    reloaded = load_m3_model(out_dir, device="cpu", dtype=torch.float32, use_cache=True)

    probe = torch.randint(0, 512, (1, 16), dtype=torch.long)
    with torch.no_grad():
        logits_orig = model(probe, use_cache=False).logits
        logits_reloaded = reloaded(probe, use_cache=False).logits
    assert (logits_orig - logits_reloaded).abs().max().item() < 1e-4


def test_normalize_rows_and_streaming_compress_roundtrip(tmp_path: Path) -> None:
    reset_cache(budget_mib=64.0, max_entry_mib=16.0)
    hf_cfg = Qwen2Config(
        vocab_size=512,
        hidden_size=128,
        intermediate_size=256,
        num_hidden_layers=2,
        num_attention_heads=4,
        num_key_value_heads=2,
    )
    model = AutoModelForCausalLM.from_config(hf_cfg).eval()
    calib = torch.randint(0, 512, (4, 32), dtype=torch.long)
    m3_cfg = M3Config.from_preset("3x8b", normalize_rows=True)
    stats = compress_causal_lm(
        model=model,
        calib_tokens=calib,
        config=m3_cfg,
        replace_modules=True,
        use_cache=True,
        device="cpu",
        offload=True,
    )
    assert stats["num_layers"] == 14
    assert stats["mean_cosine"] > 0.85

    out_dir = tmp_path / "compressed_qwen2_norm"
    save_m3_model(model, out_dir, config=m3_cfg)
    reloaded = load_m3_model(out_dir, device="cpu", dtype=torch.float32, use_cache=True)
    probe = torch.randint(0, 512, (1, 16), dtype=torch.long)
    with torch.no_grad():
        logits_orig = model(probe, use_cache=False).logits
        logits_reloaded = reloaded(probe, use_cache=False).logits
    assert (logits_orig - logits_reloaded).abs().max().item() < 1e-4


def test_cli_parser_commands() -> None:
    parser = build_parser()
    args_comp = parser.parse_args(["compress", "--model", "m", "--output", "o", "--preset", "3x7b"])
    assert args_comp.command == "compress"
    assert args_comp.preset == "3x7b"

    args_eval = parser.parse_args(["eval", "--checkpoint", "c", "--eval-tokens", "1024"])
    assert args_eval.command == "eval"

    args_bench = parser.parse_args(["benchmark", "--model", "m"])
    assert args_bench.command == "benchmark"


@pytest.mark.skipif(not torch.cuda.is_available(), reason="CUDA device required")
def test_cuda_quantize_linear_and_forward() -> None:
    reset_cache(budget_mib=16.0, max_entry_mib=8.0)
    w, h, x = _make_correlated_problem(m=256, n=256, seed=99)
    lin = nn.Linear(256, 256, bias=True).cuda().bfloat16()
    with torch.no_grad():
        lin.weight.copy_(w.cuda().bfloat16())
        lin.bias.copy_(torch.randn(256, device="cuda", dtype=torch.bfloat16))
    res, m3_lin = quantize_linear_layer(lin, h.cuda(), M3Config.from_preset("3x7b"), name="cuda_fc")
    y = m3_lin(x[:4].cuda().bfloat16())
    assert y.device.type == "cuda"
    assert y.dtype == torch.bfloat16
    assert y.shape == (4, 256)
    assert res.cosine > 0.88


def test_no_disallowed_terms_in_release_tree() -> None:
    term_en = bytes.fromhex("736f7665726569676e").decode("ascii")
    term_ar_1 = "\u0633\u064a\u0627\u062f\u064a"
    term_ar_2 = "\u0633\u064a\u0627\u062f\u064a\u0629"
    disallowed = [
        re.compile(term_en, re.IGNORECASE),
        re.compile(term_ar_1),
        re.compile(term_ar_2),
    ]
    checked = 0
    for path in PACKAGE_ROOT.rglob("*"):
        if not path.is_file():
            continue
        if any(part in {"__pycache__", ".pytest_cache", ".git", "egg-info"} for part in path.parts):
            continue
        if path.suffix in {".pyc", ".safetensors"}:
            continue
        rel = str(path.relative_to(PACKAGE_ROOT))
        text = path.read_text(encoding="utf-8", errors="ignore")
        for pat in disallowed:
            assert not pat.search(rel), f"Disallowed term in filename: {rel}"
            assert not pat.search(text), f"Disallowed term found in {rel}"
        checked += 1
    assert checked >= 8
