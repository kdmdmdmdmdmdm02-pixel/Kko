"""Command-line interface for ZAQERIS M3-GPTQ compression, evaluation, and benchmarking."""

from __future__ import annotations

import argparse
import glob
import json
import math
import os
import time
from pathlib import Path
from typing import Any

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from .core import (
    PRESET_CONFIGS,
    M3Config,
    compress_causal_lm,
    load_m3_model,
    m3_gptq_quantize,
    make_hadamard_block,
    save_m3_model,
    train_rvq_codebooks,
    quantize_8col_rvq,
)
from .runtime import M3Linear, reset_cache

_DEFAULT_FALLBACK_CORPUS = (
    "def matrix_multiply_blocked(a, b, block_size=128):\n"
    "    m, k = a.shape\n"
    "    _, n = b.shape\n"
    "    out = a.new_zeros((m, n))\n"
    "    for i in range(0, m, block_size):\n"
    "        for j in range(0, n, block_size):\n"
    "            out[i:i+block_size, j:j+block_size] = a[i:i+block_size] @ b[:, j:j+block_size]\n"
    "    return out\n\n"
    "Post-training quantization of large language models relies on accurate second-order "
    "curvature estimates from calibration activations. Block-Hadamard orthogonal transforms "
    "suppress channel outliers before residual vector codebook construction and Cholesky "
    "error propagation.\n\n"
)


def _resolve_device(device_arg: str | None) -> str:
    if device_arg:
        return device_arg
    return "cuda" if torch.cuda.is_available() else "cpu"


def _resolve_dtype(dtype_arg: str) -> torch.dtype:
    mapping = {
        "bfloat16": torch.bfloat16,
        "bf16": torch.bfloat16,
        "float16": torch.float16,
        "fp16": torch.float16,
        "float32": torch.float32,
        "fp32": torch.float32,
    }
    key = dtype_arg.lower().strip()
    if key not in mapping:
        raise ValueError(f"Unsupported dtype {dtype_arg!r}. Use bfloat16, float16, or float32.")
    return mapping[key]


def load_token_splits(
    tokenizer: Any,
    calib_tokens: int,
    eval_tokens: int,
    seq_len: int = 1024,
    corpus_dir: str | None = None,
    text_file: str | None = None,
    wikitext: bool = False,
) -> tuple[torch.Tensor, torch.Tensor]:
    """Builds `(calib_batches, eval_batches)` of shape `(N, seq_len)` from WikiText-2, local text, or fallback."""
    if wikitext:
        wt_root = Path(os.environ.get("HF_HOME", Path.home() / ".cache" / "huggingface")) / "hub" / "datasets--Salesforce--wikitext" / "snapshots"
        train_pqs = sorted(wt_root.glob("*/wikitext-2-raw-v1/train-*.parquet")) if wt_root.is_dir() else []
        test_pqs = sorted(wt_root.glob("*/wikitext-2-raw-v1/test-*.parquet")) if wt_root.is_dir() else []
        if train_pqs and test_pqs:
            import pandas as pd

            ca_text = "\n\n".join(x for x in pd.read_parquet(train_pqs[0])["text"].tolist() if x and str(x).strip())
            ev_text = "\n\n".join(x for x in pd.read_parquet(test_pqs[0])["text"].tolist() if x and str(x).strip())
        else:
            from datasets import load_dataset

            ds = load_dataset("Salesforce/wikitext", "wikitext-2-raw-v1")
            ca_text = "\n\n".join(x for x in ds["train"]["text"] if x and x.strip())
            ev_text = "\n\n".join(x for x in ds["test"]["text"] if x and x.strip())
        ca_ids = tokenizer(ca_text, return_tensors="pt", add_special_tokens=False).input_ids[0]
        ev_ids = tokenizer(ev_text, return_tensors="pt", add_special_tokens=False).input_ids[0]
    elif text_file:
        text = Path(text_file).read_text(encoding="utf-8", errors="ignore")
        ids = tokenizer(text, return_tensors="pt").input_ids[0]
        split = max(seq_len, int(ids.numel() * 0.3))
        ca_ids = ids[:split]
        ev_ids = ids[split:] if ids.numel() - split >= seq_len else ids
    elif corpus_dir:
        root = Path(corpus_dir)
        files = sorted(
            [
                *glob.glob(str(root / "**" / "*.py"), recursive=True),
                *glob.glob(str(root / "**" / "*.md"), recursive=True),
                *glob.glob(str(root / "**" / "*.txt"), recursive=True),
            ]
        )
        if not files:
            raise FileNotFoundError(f"No .py/.md/.txt files found under {corpus_dir}")
        ev_text = "\n\n".join(Path(f).read_text(encoding="utf-8", errors="ignore") for f in files[0::3])
        ca_text = "\n\n".join(Path(f).read_text(encoding="utf-8", errors="ignore") for f in files[1::3])
        if not ca_text.strip():
            ca_text = ev_text
        ev_ids = tokenizer(ev_text, return_tensors="pt").input_ids[0]
        ca_ids = tokenizer(ca_text, return_tensors="pt").input_ids[0]
    else:
        base_ids = tokenizer(_DEFAULT_FALLBACK_CORPUS, return_tensors="pt").input_ids[0]
        needed = max(calib_tokens, eval_tokens, seq_len * 2)
        reps = (needed // max(1, base_ids.numel())) + 2
        ids = base_ids.repeat(reps)
        ca_ids = ids
        ev_ids = ids

    def _slice_blocks(ids: torch.Tensor, target_tokens: int) -> torch.Tensor:
        if target_tokens <= 0:
            return torch.empty((0, seq_len), dtype=torch.long)
        n_seqs = max(1, target_tokens // seq_len)
        usable = (ids.numel() // seq_len) * seq_len
        if usable < seq_len:
            reps = (seq_len * n_seqs // max(1, ids.numel())) + 1
            ids = ids.repeat(reps)
            usable = (ids.numel() // seq_len) * seq_len
        blocks = ids[:usable].view(-1, seq_len)
        if blocks.shape[0] < n_seqs:
            reps = (n_seqs // blocks.shape[0]) + 1
            blocks = blocks.repeat(reps, 1)
        return blocks[:n_seqs]

    return _slice_blocks(ca_ids, calib_tokens), _slice_blocks(ev_ids, eval_tokens)


@torch.no_grad()
def evaluate_perplexity(
    model: torch.nn.Module,
    eval_batches: torch.Tensor,
    device: str | torch.device,
    batch_size: int = 1,
) -> float:
    """Computes exact next-token cross-entropy perplexity across `eval_batches`.

    Automatically streams block-by-block on `device` when the model lives on CPU
    while `device` is CUDA (e.g., 7B BF16 baseline inside 8 GB VRAM).
    """
    target_device = torch.device(device)
    model.eval()
    first_dev = next(model.parameters(), None)
    use_streaming = (
        target_device.type == "cuda"
        and first_dev is not None
        and first_dev.device.type == "cpu"
    )
    if not use_streaming:
        total_nll = 0.0
        total_tokens = 0
        for i in range(0, eval_batches.shape[0], batch_size):
            batch = eval_batches[i : i + batch_size].to(target_device)
            out = model(batch, use_cache=False) if hasattr(model, "config") else model(batch)
            logits = out.logits[:, :-1].float()
            targets = batch[:, 1:].reshape(-1)
            total_nll += torch.nn.functional.cross_entropy(
                logits.reshape(-1, logits.shape[-1]),
                targets,
                reduction="sum",
            ).item()
            total_tokens += targets.numel()
            del batch, out, logits
        return math.exp(total_nll / max(1, total_tokens))

    from .core import _compute_embed_hidden_and_kwargs, _discover_transformer_blocks, _run_block_streaming

    h_cpu, kw_cpu = _compute_embed_hidden_and_kwargs(model, eval_batches, target_device, batch_size=batch_size)
    for _, block in _discover_transformer_blocks(model):
        block.to(target_device)
        h_cpu = _run_block_streaming(block, h_cpu, kw_cpu, target_device, batch_size=batch_size)
        block.to("cpu")
        torch.cuda.empty_cache()

    backbone = getattr(model, "model", None) or getattr(model, "transformer", None)
    norm = getattr(backbone, "norm", None) or getattr(backbone, "ln_f", None)
    lm_head = getattr(model, "lm_head", None)
    if norm is not None:
        norm.to(target_device)
    if lm_head is not None:
        lm_head.to(target_device)

    total_nll = 0.0
    total_tokens = 0
    for i in range(0, eval_batches.shape[0], batch_size):
        hb = h_cpu[i : i + batch_size].to(target_device)
        if norm is not None:
            hb = norm(hb)
        logits = (lm_head(hb) if lm_head is not None else hb)[:, :-1].float()
        targets = eval_batches[i : i + batch_size, 1:].to(target_device).reshape(-1)
        total_nll += torch.nn.functional.cross_entropy(
            logits.reshape(-1, logits.shape[-1]),
            targets,
            reduction="sum",
        ).item()
        total_tokens += targets.numel()
        del hb, logits, targets

    if norm is not None:
        norm.to("cpu")
    if lm_head is not None:
        lm_head.to("cpu")
    torch.cuda.empty_cache()
    return math.exp(total_nll / max(1, total_tokens))


def _load_hf_model(model_path: str, dtype: torch.dtype, device: str) -> torch.nn.Module:
    try:
        model = AutoModelForCausalLM.from_pretrained(model_path, dtype=dtype)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(model_path, torch_dtype=dtype)
    model = model.to(device).eval()
    if hasattr(model, "config") and hasattr(model.config, "use_cache"):
        model.config.use_cache = False
    model.requires_grad_(False)
    return model


def _build_config_from_args(args: argparse.Namespace) -> M3Config:
    overrides: dict[str, Any] = {}
    if getattr(args, "stages", None) is not None:
        overrides["stages"] = args.stages
    if getattr(args, "cb_size", None) is not None:
        overrides["cb_size"] = args.cb_size
    if getattr(args, "outlier_ratio", None) is not None:
        overrides["outlier_ratio"] = args.outlier_ratio
    return M3Config.from_preset(args.preset, **overrides)


def _cmd_compress(args: argparse.Namespace) -> None:
    device = _resolve_device(args.device)
    dtype = _resolve_dtype(args.dtype)
    cfg = _build_config_from_args(args)

    t0 = time.time()
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    calib, ev = load_token_splits(
        tokenizer,
        calib_tokens=args.calib_tokens,
        eval_tokens=args.eval_tokens,
        seq_len=args.seq_len,
        corpus_dir=args.corpus_dir,
        text_file=args.calib_file,
    )
    model = _load_hf_model(args.model, dtype=dtype, device=device)

    stats = compress_causal_lm(
        model=model,
        calib_tokens=calib,
        config=cfg,
        replace_modules=True,
        use_cache=not args.no_cache,
        device=device,
    )
    out_dir = save_m3_model(model, args.output, config=cfg)
    tokenizer.save_pretrained(str(out_dir))

    summary: dict[str, Any] = {
        "model": args.model,
        "output": str(out_dir),
        "preset": args.preset,
        "effective_bpw": round(stats["effective_bpw"], 4),
        "mean_rel_l2": round(stats["mean_rel_l2"], 5),
        "mean_cosine": round(stats["mean_cosine"], 5),
        "num_layers_quantized": stats["num_layers"],
        "storage_mib": round(stats["total_storage_bytes"] / (1024 * 1024), 2),
        "elapsed_seconds": round(time.time() - t0, 2),
    }
    if ev.shape[0] > 0:
        summary["eval_ppl"] = round(evaluate_perplexity(model, ev, device=device), 4)
    print(json.dumps(summary, indent=2))


def _cmd_eval(args: argparse.Namespace) -> None:
    device = _resolve_device(args.device)
    dtype = _resolve_dtype(args.dtype)
    reset_cache()

    model_src = args.checkpoint or args.model
    if not model_src:
        raise ValueError("Provide either --checkpoint (compressed M3 dir) or --model")

    tokenizer = AutoTokenizer.from_pretrained(model_src)
    _, ev = load_token_splits(
        tokenizer,
        calib_tokens=0,
        eval_tokens=args.eval_tokens,
        seq_len=args.seq_len,
        corpus_dir=args.corpus_dir,
        text_file=args.eval_file,
    )
    if args.checkpoint:
        model = load_m3_model(args.checkpoint, device=device, dtype=dtype, use_cache=not args.no_cache)
    else:
        model = _load_hf_model(args.model, dtype=dtype, device=device)

    t0 = time.time()
    ppl = evaluate_perplexity(model, ev, device=device)
    elapsed = time.time() - t0
    m3_bytes = sum(m.storage_bytes for m in model.modules() if isinstance(m, M3Linear))

    result = {
        "source": model_src,
        "eval_tokens": int(ev.numel()),
        "perplexity": round(ppl, 4),
        "m3_storage_mib": round(m3_bytes / (1024 * 1024), 2) if m3_bytes > 0 else None,
        "elapsed_seconds": round(elapsed, 2),
        "tokens_per_second": round(ev.numel() / max(1e-6, elapsed), 1),
    }
    print(json.dumps(result, indent=2))


@torch.no_grad()
def _run_hadamard_rvq_only(
    model: torch.nn.Module,
    orig_cpu: dict[str, torch.Tensor],
    r_g: torch.Tensor,
    device: str,
    stages: int = 3,
    cb_size: int = 256,
    outlier_ratio: float = 0.005,
) -> tuple[float, float, float]:
    """Baseline non-Hessian Hadamard+RVQ quantization for direct ablation."""
    total_bytes, total_params = 0, 0
    rels, coss = [], []
    linear_mods = {
        n: m
        for n, m in model.named_modules()
        if isinstance(m, torch.nn.Linear) and "lm_head" not in n
    }
    for name, mod in linear_mods.items():
        w0 = orig_cpu[name].to(device=device, dtype=torch.float32)
        m, n = w0.shape
        g = r_g.shape[0]
        w_rot = (w0.view(m, n // g, g) @ r_g).reshape(m, n).clone()
        total = m * n
        n_out = max(1, int(total * outlier_ratio))
        thresh = torch.topk(w_rot.abs().reshape(-1), n_out).values[-1]
        out_mask = w_rot.abs() >= thresh
        if int(out_mask.sum().item()) > n_out:
            nz = torch.nonzero(out_mask, as_tuple=False)
            top_idx = torch.topk(w_rot[nz[:, 0], nz[:, 1]].abs(), n_out).indices
            out_mask.zero_()
            sel = nz[top_idx]
            out_mask[sel[:, 0], sel[:, 1]] = True
        actual_out = int(out_mask.sum().item())

        w_src = w_rot.clone()
        w_src[out_mask] = 0.0
        cbs = train_rvq_codebooks(w_src.reshape(-1, 8), name=name, stages=stages, cb_size=cb_size, iters=8)
        q_vecs = quantize_8col_rvq(w_src.reshape(-1, 8), cbs)
        q_rot = q_vecs.reshape(m, n)
        q_rot[out_mask] = w_rot[out_mask].half().float()
        w_hat = (q_rot.view(m, n // g, g) @ r_g.t()).reshape(m, n)

        mod.weight.copy_(w_hat.to(mod.weight.dtype))
        idx_bits = max(1, int(math.ceil(math.log2(cb_size))))
        num_vecs = total // 8
        total_bytes += stages * (cb_size * 8 * 2 + (num_vecs * idx_bits + 7) // 8) + actual_out * 6 + 12
        total_params += total
        rels.append(((w_hat - w0).norm() / w0.norm().clamp_min(1e-12)).item())
        coss.append(torch.nn.functional.cosine_similarity(w_hat.reshape(1, -1), w0.reshape(1, -1)).item())
    return total_bytes * 8.0 / total_params, sum(rels) / len(rels), sum(coss) / len(coss)


def _cmd_benchmark(args: argparse.Namespace) -> None:
    device = _resolve_device(args.device)
    dtype = _resolve_dtype(args.dtype)
    if device == "cuda":
        torch.cuda.reset_peak_memory_stats()

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    calib, ev = load_token_splits(
        tokenizer,
        calib_tokens=args.calib_tokens,
        eval_tokens=args.eval_tokens,
        seq_len=args.seq_len,
        corpus_dir=args.corpus_dir,
        text_file=args.eval_file,
    )
    model = _load_hf_model(args.model, dtype=dtype, device=device)
    base_ppl = evaluate_perplexity(model, ev, device=device)

    linear_mods = {
        n: m
        for n, m in model.named_modules()
        if isinstance(m, torch.nn.Linear) and "lm_head" not in n
    }
    orig_cpu = {n: m.weight.detach().clone().cpu() for n, m in linear_mods.items()}
    r_g = make_hadamard_block(block_dim=128, seed=1234, device=device)

    results: dict[str, Any] = {
        "model": args.model,
        "baseline_ppl": round(base_ppl, 4),
        "calib_tokens": int(calib.numel()),
        "eval_tokens": int(ev.numel()),
        "runs": [],
    }

    def _restore() -> None:
        for n, m in linear_mods.items():
            m.weight.copy_(orig_cpu[n].to(device=device, dtype=m.weight.dtype))
        if device == "cuda":
            torch.cuda.empty_cache()

    if args.include_non_hessian:
        t_run = time.time()
        bpw, rel_l2, cos = _run_hadamard_rvq_only(model, orig_cpu, r_g, device=device)
        p = evaluate_perplexity(model, ev, device=device)
        results["runs"].append(
            {
                "method": "Hadamard + RVQ (3x8b, no Hessian)",
                "effective_bpw": round(bpw, 4),
                "mean_rel_l2": round(rel_l2, 5),
                "mean_cosine": round(cos, 5),
                "ppl": round(p, 4),
                "ratio": round(p / base_ppl, 4),
                "seconds": round(time.time() - t_run, 1),
            }
        )
        _restore()

    for preset in args.presets:
        cfg = M3Config.from_preset(preset)
        t_run = time.time()
        stats = compress_causal_lm(
            model=model,
            calib_tokens=calib,
            config=cfg,
            replace_modules=False,
            device=device,
        )
        p = evaluate_perplexity(model, ev, device=device)
        results["runs"].append(
            {
                "method": f"M3-GPTQ ({preset})",
                "effective_bpw": round(stats["effective_bpw"], 4),
                "mean_rel_l2": round(stats["mean_rel_l2"], 5),
                "mean_cosine": round(stats["mean_cosine"], 5),
                "ppl": round(p, 4),
                "ratio": round(p / base_ppl, 4),
                "storage_mib": round(stats["total_storage_bytes"] / (1024 * 1024), 2),
                "seconds": round(time.time() - t_run, 1),
            }
        )
        _restore()

    if device == "cuda":
        results["peak_vram_gib"] = round(torch.cuda.max_memory_allocated() / (1024**3), 3)

    if args.output_json:
        out_path = Path(args.output_json)
        out_path.parent.mkdir(parents=True, exist_ok=True)
        out_path.write_text(json.dumps(results, indent=2), encoding="utf-8")

    print(json.dumps(results, indent=2))


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="zaqeris-m3",
        description="ZAQERIS M3-GPTQ quantization, evaluation, and benchmark CLI.",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    p_comp = sub.add_parser("compress", help="Compress a CausalLM model with M3-GPTQ.")
    p_comp.add_argument("--model", required=True, help="HuggingFace model ID or local checkpoint path.")
    p_comp.add_argument("--output", required=True, help="Output directory for compressed checkpoint.")
    p_comp.add_argument("--preset", default="3x7b", choices=sorted(PRESET_CONFIGS.keys()))
    p_comp.add_argument("--stages", type=int, default=None)
    p_comp.add_argument("--cb-size", type=int, default=None)
    p_comp.add_argument("--outlier-ratio", type=float, default=None)
    p_comp.add_argument("--calib-tokens", type=int, default=32768)
    p_comp.add_argument("--eval-tokens", type=int, default=0)
    p_comp.add_argument("--seq-len", type=int, default=1024)
    p_comp.add_argument("--corpus-dir", default=None)
    p_comp.add_argument("--calib-file", default=None)
    p_comp.add_argument("--device", default=None)
    p_comp.add_argument("--dtype", default="bfloat16")
    p_comp.add_argument("--no-cache", action="store_true")
    p_comp.set_defaults(func=_cmd_compress)

    p_eval = sub.add_parser("eval", help="Evaluate perplexity of a compressed or baseline model.")
    p_eval.add_argument("--checkpoint", default=None, help="Compressed M3 checkpoint directory.")
    p_eval.add_argument("--model", default=None, help="Uncompressed HuggingFace/local model.")
    p_eval.add_argument("--eval-tokens", type=int, default=65536)
    p_eval.add_argument("--seq-len", type=int, default=1024)
    p_eval.add_argument("--corpus-dir", default=None)
    p_eval.add_argument("--eval-file", default=None)
    p_eval.add_argument("--device", default=None)
    p_eval.add_argument("--dtype", default="bfloat16")
    p_eval.add_argument("--no-cache", action="store_true")
    p_eval.set_defaults(func=_cmd_eval)

    p_bench = sub.add_parser("benchmark", help="Run BF16 vs Hadamard+RVQ vs M3-GPTQ benchmark.")
    p_bench.add_argument("--model", required=True, help="HuggingFace model ID or local checkpoint path.")
    p_bench.add_argument(
        "--presets",
        nargs="+",
        default=["3x8b_tight", "3x7b", "4x5b", "3x6b", "2x8b"],
        choices=sorted(PRESET_CONFIGS.keys()),
    )
    p_bench.add_argument("--no-non-hessian", dest="include_non_hessian", action="store_false")
    p_bench.add_argument("--calib-tokens", type=int, default=32768)
    p_bench.add_argument("--eval-tokens", type=int, default=98304)
    p_bench.add_argument("--seq-len", type=int, default=1024)
    p_bench.add_argument("--corpus-dir", default=None)
    p_bench.add_argument("--eval-file", default=None)
    p_bench.add_argument("--output-json", default=None)
    p_bench.add_argument("--device", default=None)
    p_bench.add_argument("--dtype", default="bfloat16")
    p_bench.set_defaults(func=_cmd_benchmark)

    return parser


def main(argv: list[str] | None = None) -> None:
    parser = build_parser()
    args = parser.parse_args(argv)
    args.func(args)


if __name__ == "__main__":
    main()
