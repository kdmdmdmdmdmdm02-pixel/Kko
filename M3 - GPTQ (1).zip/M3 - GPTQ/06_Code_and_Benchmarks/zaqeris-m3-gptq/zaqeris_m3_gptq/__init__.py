"""ZAQERIS M3-GPTQ public package interface."""

from .core import (
    PRESET_CONFIGS,
    M3Config,
    M3GPTQResult,
    compress_causal_lm,
    dequantize_m3_weight,
    load_m3_layer,
    load_m3_model,
    m3_gptq_quantize,
    make_hadamard_block,
    pack_indices,
    quantize_8col_rvq,
    quantize_linear_layer,
    reconstruct_m3_matrix,
    save_m3_layer,
    save_m3_model,
    train_rvq_codebooks,
    unpack_indices,
)
from .runtime import (
    CacheStats,
    M3Linear,
    ResidentWeightCache,
    get_cache,
    is_hot_matrix,
    reset_cache,
)

__version__ = "0.1.0"

__all__ = [
    "__version__",
    "PRESET_CONFIGS",
    "M3Config",
    "M3GPTQResult",
    "M3Linear",
    "CacheStats",
    "ResidentWeightCache",
    "get_cache",
    "reset_cache",
    "is_hot_matrix",
    "make_hadamard_block",
    "train_rvq_codebooks",
    "quantize_8col_rvq",
    "pack_indices",
    "unpack_indices",
    "m3_gptq_quantize",
    "dequantize_m3_weight",
    "reconstruct_m3_matrix",
    "save_m3_layer",
    "load_m3_layer",
    "quantize_linear_layer",
    "compress_causal_lm",
    "save_m3_model",
    "load_m3_model",
]
