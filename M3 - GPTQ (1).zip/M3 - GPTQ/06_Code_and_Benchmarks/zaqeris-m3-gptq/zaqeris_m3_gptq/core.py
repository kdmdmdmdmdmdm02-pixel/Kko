"""ZAQERIS M3-GPTQ: Hessian-Aware Multi-Stage Residual Vector Quantization Engine.

Combines four complementary components for sub-3.5-bit LLM weight compression:
  1. Memory-lean Block-Hadamard (g=128) orthogonal decorrelation.
  2. OBQ Hessian-salience outlier selection: score = w^2 / [H^{-1}]_{jj}.
  3. Multi-stage 8D Euclidean Residual Vector Quantization (RVQ) codebooks
     with bit-packed indices (e.g., 3x8b, 3x7b, 4x5b, 3x6b, 2x8b).
  4. Block-8 Cholesky GPTQ error propagation eliminating cumulative drift.
"""

from __future__ import annotations

import json
import math
from dataclasses import dataclass
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
import torch.nn.functional as F
from safetensors import safe_open
from safetensors.torch import load_file, save_file
from scipy.linalg import hadamard

_PACK_CHUNK_ELEMENTS = 1_048_576  # Divisible by 8 for exact byte alignment.

PRESET_CONFIGS: dict[str, dict[str, Any]] = {
    "3x8b": {"stages": 3, "cb_size": 256, "outlier_ratio": 0.005},
    "3x8b_tight": {"stages": 3, "cb_size": 256, "outlier_ratio": 0.0025},
    "tight": {"stages": 3, "cb_size": 256, "outlier_ratio": 0.0025},
    "3x7b": {"stages": 3, "cb_size": 128, "outlier_ratio": 0.0025},
    "4x5b": {"stages": 4, "cb_size": 32, "outlier_ratio": 0.0025},
    "3x6b": {"stages": 3, "cb_size": 64, "outlier_ratio": 0.0025},
    "2x8b": {"stages": 2, "cb_size": 256, "outlier_ratio": 0.0025},
}


@dataclass(frozen=True)
class M3Config:
    """Configuration for ZAQERIS M3-GPTQ quantization."""

    stages: int = 3
    cb_size: int = 128
    outlier_ratio: float = 0.0025
    group_size: int = 128
    vec_dim: int = 8
    damp: float = 0.01
    kmeans_iters: int = 8
    hadamard_seed: int = 1234
    normalize_rows: bool = False

    def __post_init__(self) -> None:
        if self.stages < 1:
            raise ValueError("stages must be >= 1")
        if self.cb_size < 2 or self.cb_size > 256 or (self.cb_size & (self.cb_size - 1)) != 0:
            raise ValueError("cb_size must be a power of 2 in [2, 256]")
        if not 0.0 <= self.outlier_ratio < 1.0:
            raise ValueError("outlier_ratio must be in [0.0, 1.0)")
        if self.vec_dim < 1:
            raise ValueError("vec_dim must be >= 1")
        if self.group_size < self.vec_dim or self.group_size % self.vec_dim != 0:
            raise ValueError("group_size must be a multiple of vec_dim")
        if (self.group_size & (self.group_size - 1)) != 0:
            raise ValueError("group_size must be a power of 2")

    @property
    def idx_bits(self) -> int:
        """Bits per RVQ codebook index."""
        return max(1, int(math.ceil(math.log2(self.cb_size))))

    @classmethod
    def from_preset(cls, preset: str, **overrides: Any) -> M3Config:
        """Builds an M3Config from a named bitrate preset."""
        key = preset.lower().strip()
        if key not in PRESET_CONFIGS:
            valid = ", ".join(sorted(PRESET_CONFIGS))
            raise ValueError(f"Unknown preset {preset!r}. Expected one of: {valid}")
        params = dict(PRESET_CONFIGS[key])
        params.update(overrides)
        return cls(**params)


@dataclass
class M3GPTQResult:
    """Container for one M3-GPTQ quantized weight matrix and quality metrics."""

    w_hat: torch.Tensor | None
    codebooks: list[torch.Tensor]
    packed_indices: torch.Tensor
    outlier_coords: torch.Tensor
    outlier_vals: torch.Tensor
    shape: tuple[int, int]
    stages: int
    cb_size: int
    group_size: int
    vec_dim: int
    hadamard_seed: int
    storage_bytes: int
    rel_l2: float
    cosine: float
    row_scales: torch.Tensor | None = None

    @property
    def effective_bpw(self) -> float:
        """Effective bits per weight including codebooks, indices, outliers, and metadata."""
        total = self.shape[0] * self.shape[1]
        return (self.storage_bytes * 8.0 / total) if total > 0 else 0.0


def _resolve_group_size(in_features: int, requested_group_size: int, vec_dim: int) -> int:
    """Selects the largest valid power-of-two Hadamard group size dividing in_features."""
    if in_features % vec_dim != 0:
        raise ValueError(
            f"in_features ({in_features}) must be divisible by vec_dim ({vec_dim})"
        )
    if in_features % requested_group_size == 0:
        return requested_group_size
    g = requested_group_size
    while g >= vec_dim:
        if in_features % g == 0:
            return g
        g //= 2
    return vec_dim


def pack_indices(indices: torch.Tensor, bits: int) -> torch.Tensor:
    """Packs integer indices in [0, 2^bits - 1] into a compact uint8 tensor.

    Supports 1D `(N,)` or 2D `(stages, N)` inputs.
    """
    if not 1 <= bits <= 8:
        raise ValueError(f"bits must be in [1, 8], got {bits}")
    if indices.ndim == 2:
        return torch.stack([pack_indices(row, bits) for row in indices], dim=0)
    if indices.ndim != 1:
        raise ValueError(f"Expected 1D or 2D indices, got shape {tuple(indices.shape)}")

    flat = indices.contiguous()
    n = flat.numel()
    if bits == 8:
        return flat.to(torch.uint8)
    if bits == 4:
        if n % 2 != 0:
            flat = F.pad(flat, (0, 1))
        pairs = flat.to(torch.uint8).view(-1, 2)
        return (pairs[:, 0] | (pairs[:, 1] << 4)).contiguous()

    n_bytes = (n * bits + 7) // 8
    out = torch.zeros(n_bytes, device=flat.device, dtype=torch.uint8)
    for start in range(0, n, _PACK_CHUNK_ELEMENTS):
        end = min(start + _PACK_CHUNK_ELEMENTS, n)
        chunk = flat[start:end]
        chunk_len = chunk.numel()
        chunk_bytes = (chunk_len * bits + 7) // 8
        byte_start = (start * bits) // 8

        pos = torch.arange(chunk_len, device=flat.device, dtype=torch.int64) * bits
        b0 = pos // 8
        off = (pos % 8).to(torch.int32)
        vals = chunk.to(torch.int32)

        buf = torch.zeros(chunk_bytes, device=flat.device, dtype=torch.int32)
        buf.index_add_(0, b0, (vals << off) & 0xFF)
        spill = (off + bits) > 8
        if bool(spill.any()):
            buf.index_add_(0, b0[spill] + 1, vals[spill] >> (8 - off[spill]))
        out[byte_start : byte_start + chunk_bytes] = buf.to(torch.uint8)
    return out


def unpack_indices(packed: torch.Tensor, num_elements: int, bits: int) -> torch.Tensor:
    """Unpacks a uint8 tensor produced by `pack_indices` into int64 indices."""
    if not 1 <= bits <= 8:
        raise ValueError(f"bits must be in [1, 8], got {bits}")
    if packed.ndim == 2:
        return torch.stack(
            [unpack_indices(row, num_elements, bits) for row in packed], dim=0
        )
    if packed.ndim != 1:
        raise ValueError(f"Expected 1D or 2D packed tensor, got shape {tuple(packed.shape)}")

    if bits == 8:
        return packed[:num_elements].to(torch.int64)
    if bits == 4:
        low = (packed & 0x0F).to(torch.int64)
        high = ((packed >> 4) & 0x0F).to(torch.int64)
        return torch.stack((low, high), dim=1).reshape(-1)[:num_elements]

    mask = (1 << bits) - 1
    out = torch.empty(num_elements, device=packed.device, dtype=torch.int64)
    for start in range(0, num_elements, _PACK_CHUNK_ELEMENTS):
        end = min(start + _PACK_CHUNK_ELEMENTS, num_elements)
        chunk_len = end - start
        chunk_bytes = (chunk_len * bits + 7) // 8
        byte_start = (start * bits) // 8

        chunk_packed = F.pad(packed[byte_start : byte_start + chunk_bytes], (0, 1))
        pos = torch.arange(chunk_len, device=packed.device, dtype=torch.int64) * bits
        b0 = pos // 8
        off = (pos % 8).to(torch.int32)
        pair = chunk_packed[b0].to(torch.int32) | (chunk_packed[b0 + 1].to(torch.int32) << 8)
        out[start:end] = ((pair >> off) & mask).to(torch.int64)
    return out


def make_hadamard_block(
    block_dim: int = 128,
    seed: int = 1234,
    device: str | torch.device = "cuda",
) -> torch.Tensor:
    """Constructs a randomized orthonormal Block-Hadamard rotation matrix."""
    hd = torch.tensor(hadamard(block_dim), dtype=torch.float32, device=device) / math.sqrt(block_dim)
    gen = torch.Generator(device="cpu").manual_seed(seed)
    signs = (torch.randint(0, 2, (block_dim,), generator=gen).float() * 2.0 - 1.0).to(device)
    return signs[:, None] * hd


def train_rvq_codebooks(
    vecs_in: torch.Tensor,
    name: str,
    stages: int = 3,
    cb_size: int = 128,
    iters: int = 8,
) -> list[torch.Tensor]:
    """Trains multi-stage 8D RVQ codebooks via batched Euclidean k-means."""
    num_vecs = vecs_in.shape[0]
    n_sample = min(32768, num_vecs)
    gen = torch.Generator(device=vecs_in.device).manual_seed(
        ((num_vecs * 131) ^ len(name)) & 0x7FFFFFFF
    )
    samp = vecs_in[torch.randperm(num_vecs, generator=gen, device=vecs_in.device)[:n_sample]].float().clone()

    if samp.shape[0] < cb_size:
        repeat_factor = (cb_size + samp.shape[0] - 1) // samp.shape[0]
        init_pool = samp.repeat(repeat_factor, 1)
    else:
        init_pool = samp

    cbs: list[torch.Tensor] = []
    for _ in range(stages):
        cb = init_pool[:cb_size].clone()
        for _ in range(iters):
            cb_n2 = cb.pow(2).sum(dim=1, keepdim=True).T
            assign = torch.argmin(torch.addmm(cb_n2, samp, cb.T, beta=1.0, alpha=-2.0), dim=1)
            new_cb = torch.zeros_like(cb)
            cnt = torch.zeros((cb_size, 1), device=vecs_in.device)
            new_cb.index_add_(0, assign, samp)
            cnt.index_add_(0, assign, torch.ones((assign.shape[0], 1), device=vecs_in.device))
            valid = cnt.squeeze(1) > 0
            new_cb[valid] = new_cb[valid] / cnt[valid]
            cb = new_cb
        cb_h = cb.half()
        cbs.append(cb_h)
        cb_n2 = cb.pow(2).sum(dim=1, keepdim=True).T
        assign = torch.argmin(torch.addmm(cb_n2, samp, cb.T, beta=1.0, alpha=-2.0), dim=1)
        samp = samp - cb_h[assign].float()
        init_pool = samp if samp.shape[0] >= cb_size else samp.repeat((cb_size + samp.shape[0] - 1) // samp.shape[0], 1)
    return cbs


def quantize_8col_rvq(
    blk: torch.Tensor,
    cbs: list[torch.Tensor],
    return_indices: bool = False,
) -> torch.Tensor | tuple[torch.Tensor, torch.Tensor]:
    """Quantizes an `(m, vec_dim)` block against multi-stage RVQ codebooks."""
    res = blk.float()
    q_tot = torch.zeros_like(res)
    stage_indices: list[torch.Tensor] = []
    for cb_h in cbs:
        cb = cb_h.float()
        cb_n2 = cb.pow(2).sum(dim=1, keepdim=True).T
        assign = torch.argmin(torch.addmm(cb_n2, res, cb.T, beta=1.0, alpha=-2.0), dim=1)
        picked = cb[assign]
        q_tot += picked
        res = res - picked
        if return_indices:
            stage_indices.append(assign)
    if return_indices:
        return q_tot, torch.stack(stage_indices, dim=0)
    return q_tot


def _compute_cholesky_inverse_upper(h_rot: torch.Tensor, damp: float) -> torch.Tensor:
    """Computes upper-triangular Cholesky factor of H^{-1} with damping fallback."""
    n = h_rot.shape[0]
    diag_mean = torch.diag(h_rot).mean().clamp_min(1e-8)
    eye = torch.eye(n, device=h_rot.device, dtype=h_rot.dtype)
    for scale in (1.0, 10.0, 100.0, 1000.0):
        try:
            h_damped = h_rot + (damp * scale) * diag_mean * eye
            chol = torch.linalg.cholesky(h_damped)
            return torch.linalg.cholesky(torch.cholesky_inverse(chol), upper=True)
        except torch.linalg.LinAlgError:
            continue
    raise torch.linalg.LinAlgError("Failed Cholesky factorization of Hessian even with escalated damping")


@torch.no_grad()
def m3_gptq_quantize(
    w_in: torch.Tensor,
    h_in: torch.Tensor,
    r_g: torch.Tensor | None = None,
    name: str = "weight",
    outlier_ratio: float = 0.0025,
    stages: int = 3,
    cb_size: int = 128,
    damp: float = 0.01,
    vec_dim: int = 8,
    kmeans_iters: int = 8,
    hadamard_seed: int = 1234,
    normalize_rows: bool = False,
) -> M3GPTQResult:
    """Applies Block-Hadamard + OBQ Salience + Multi-Stage RVQ + Block-8 GPTQ error feedback."""
    w_orig = w_in.float()
    if normalize_rows:
        rs = w_orig.std(dim=1, keepdim=True).clamp_min(1e-6)
        w0 = w_orig / rs
        row_scales_cpu = rs.squeeze(1).half().cpu()
    else:
        w0 = w_orig
        row_scales_cpu = None
    m, n = w0.shape
    total = m * n

    if r_g is None:
        g = _resolve_group_size(n, 128, vec_dim)
        r_g = make_hadamard_block(block_dim=g, seed=hadamard_seed, device=w0.device)
    else:
        r_g = r_g.to(device=w0.device, dtype=torch.float32)
        g = r_g.shape[0]

    if n % g != 0:
        raise ValueError(f"Weight input dim ({n}) must be divisible by Hadamard group size ({g})")
    if n % vec_dim != 0:
        raise ValueError(f"Weight input dim ({n}) must be divisible by vec_dim ({vec_dim})")

    w_rot = (w0.view(m, n // g, g) @ r_g).reshape(m, n).clone()
    h_rot = torch.einsum(
        "ic,aibj,jd->acbd",
        r_g,
        h_in.to(device=w0.device, dtype=torch.float32).view(n // g, g, n // g, g),
        r_g,
    ).reshape(n, n)

    dead = torch.diag(h_rot) == 0
    h_rot[dead, dead] = 1.0
    w_rot[:, dead] = 0.0

    h_inv = _compute_cholesky_inverse_upper(h_rot, damp=damp)
    diag_hinv = h_inv.pow(2).sum(dim=0).clamp_min(1e-12)

    if outlier_ratio > 0.0:
        n_out = max(1, int(total * outlier_ratio))
        salience = (w_rot.pow(2) / diag_hinv[None, :]).reshape(-1)
        if total > 8_388_608:
            step = max(1, total // 2_097_152)
            thresh = torch.topk(salience[::step], max(1, n_out // step)).values[-1]
        else:
            thresh = torch.topk(salience, n_out).values[-1]
        out_mask = (w_rot.pow(2) / diag_hinv[None, :]) >= thresh
        if int(out_mask.sum().item()) > n_out:
            nz = torch.nonzero(out_mask, as_tuple=False)
            top_idx = torch.topk(
                w_rot[nz[:, 0], nz[:, 1]].pow(2) / diag_hinv[nz[:, 1]],
                n_out,
            ).indices
            out_mask.zero_()
            sel = nz[top_idx]
            out_mask[sel[:, 0], sel[:, 1]] = True
        del salience
    else:
        out_mask = torch.zeros((m, n), dtype=torch.bool, device=w_rot.device)

    actual_out = int(out_mask.sum().item())

    w_cb_src = w_rot.clone()
    w_cb_src[out_mask] = 0.0
    cbs = train_rvq_codebooks(
        w_cb_src.reshape(-1, vec_dim),
        name=name,
        stages=stages,
        cb_size=cb_size,
        iters=kmeans_iters,
    )
    del w_cb_src

    nb = n // vec_dim
    idx_b = torch.arange(nb, device=w_rot.device)
    inv_diag_blocks = torch.linalg.inv(h_inv.view(nb, vec_dim, nb, vec_dim)[idx_b, :, idx_b, :])

    q_rot = torch.zeros_like(w_rot)
    w_cur = w_rot.clone()
    all_indices = torch.empty((stages, m, nb), dtype=torch.int64, device=w_rot.device)

    for b_idx in range(nb):
        g0, g1 = b_idx * vec_dim, (b_idx + 1) * vec_dim
        blk_orig = w_cur[:, g0:g1]
        mask_blk = out_mask[:, g0:g1]
        blk_for_rvq = blk_orig.clone()
        blk_for_rvq[mask_blk] = 0.0
        q_blk, blk_idx = quantize_8col_rvq(blk_for_rvq, cbs, return_indices=True)
        q_blk[mask_blk] = blk_orig[mask_blk].half().float()
        q_rot[:, g0:g1] = q_blk
        all_indices[:, :, b_idx] = blk_idx
        if g1 < n:
            e_j = (blk_orig - q_blk) @ inv_diag_blocks[b_idx]
            w_cur[:, g1:] -= e_j @ h_inv[g0:g1, g1:]

    w_hat = (q_rot.view(m, n // g, g) @ r_g.t()).reshape(m, n)
    if normalize_rows:
        w_hat = w_hat * rs

    coord_dtype = torch.uint16 if (m <= 65535 and n <= 65535) else torch.int32
    coord_bytes = 4 if coord_dtype == torch.uint16 else 8
    out_nz = torch.nonzero(out_mask, as_tuple=False).to(coord_dtype).cpu()
    out_vals = q_rot[out_mask].half().cpu()

    idx_bits = max(1, int(math.ceil(math.log2(cb_size))))
    packed_indices = pack_indices(all_indices.reshape(stages, m * nb), bits=idx_bits).cpu()

    num_vecs = total // vec_dim
    scale_bytes = (m * 2) if normalize_rows else 0
    storage_bytes = (
        stages * (cb_size * vec_dim * 2 + (num_vecs * idx_bits + 7) // 8)
        + actual_out * (2 + coord_bytes)
        + scale_bytes
        + 12
    )
    rel_l2 = ((w_hat - w_orig).norm() / w_orig.norm().clamp_min(1e-12)).item()
    cos = F.cosine_similarity(w_hat.reshape(1, -1), w_orig.reshape(1, -1)).item()

    return M3GPTQResult(
        w_hat=w_hat,
        codebooks=[c.cpu() for c in cbs],
        packed_indices=packed_indices,
        outlier_coords=out_nz,
        outlier_vals=out_vals,
        shape=(m, n),
        stages=stages,
        cb_size=cb_size,
        group_size=g,
        vec_dim=vec_dim,
        hadamard_seed=hadamard_seed,
        storage_bytes=storage_bytes,
        rel_l2=rel_l2,
        cosine=cos,
        row_scales=row_scales_cpu,
    )


@torch.no_grad()
def reconstruct_m3_matrix(
    codebooks: list[torch.Tensor] | torch.Tensor,
    packed_indices: torch.Tensor,
    outlier_coords: torch.Tensor,
    outlier_vals: torch.Tensor,
    shape: tuple[int, int],
    group_size: int,
    vec_dim: int,
    hadamard_seed: int,
    device: str | torch.device = "cpu",
    dtype: torch.dtype = torch.float32,
    r_g: torch.Tensor | None = None,
    row_scales: torch.Tensor | None = None,
) -> torch.Tensor:
    """Reconstructs a dense weight matrix `(m, n)` from M3-GPTQ compressed buffers."""
    m, n = shape
    nb = n // vec_dim
    num_vecs = m * nb
    stages = len(codebooks) if isinstance(codebooks, list) else int(codebooks.shape[0])
    cb_size = int(codebooks[0].shape[0])
    idx_bits = max(1, int(math.ceil(math.log2(cb_size))))

    idx = unpack_indices(packed_indices.to(device), num_vecs, idx_bits)
    q_vecs = torch.zeros((num_vecs, vec_dim), device=device, dtype=torch.float32)
    for s in range(stages):
        cb = codebooks[s].to(device=device, dtype=torch.float32)
        q_vecs.add_(cb[idx[s]])

    q_rot = q_vecs.view(m, n)
    if outlier_vals.numel() > 0:
        coords = outlier_coords.to(device=device, dtype=torch.long)
        q_rot[coords[:, 0], coords[:, 1]] = outlier_vals.to(device=device, dtype=torch.float32)

    if r_g is None:
        r_g = make_hadamard_block(block_dim=group_size, seed=hadamard_seed, device=device)
    else:
        r_g = r_g.to(device=device, dtype=torch.float32)

    w_hat = (q_rot.view(m, n // group_size, group_size) @ r_g.t()).reshape(m, n)
    if row_scales is not None:
        w_hat = w_hat * row_scales.to(device=device, dtype=torch.float32).unsqueeze(1)
    return w_hat.to(dtype=dtype)


@torch.no_grad()
def dequantize_m3_weight(
    result: M3GPTQResult,
    device: str | torch.device = "cpu",
    dtype: torch.dtype = torch.float32,
    r_g: torch.Tensor | None = None,
) -> torch.Tensor:
    """Reconstructs a dense weight matrix from an `M3GPTQResult`."""
    return reconstruct_m3_matrix(
        codebooks=result.codebooks,
        packed_indices=result.packed_indices,
        outlier_coords=result.outlier_coords,
        outlier_vals=result.outlier_vals,
        shape=result.shape,
        group_size=result.group_size,
        vec_dim=result.vec_dim,
        hadamard_seed=result.hadamard_seed,
        device=device,
        dtype=dtype,
        r_g=r_g,
        row_scales=result.row_scales,
    )


def save_m3_layer(result: M3GPTQResult, path: str | Path) -> Path:
    """Serializes one quantized M3-GPTQ layer to a SafeTensors file."""
    out_path = Path(path)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    tensors = {
        "codebooks": torch.stack([c.cpu().half() for c in result.codebooks], dim=0),
        "packed_indices": result.packed_indices.cpu().contiguous(),
        "outlier_coords": result.outlier_coords.cpu().contiguous(),
        "outlier_vals": result.outlier_vals.cpu().half().contiguous(),
    }
    if result.row_scales is not None:
        tensors["row_scales"] = result.row_scales.cpu().half().contiguous()
    metadata = {
        "format": "zaqeris_m3_gptq_v1",
        "shape_0": str(result.shape[0]),
        "shape_1": str(result.shape[1]),
        "stages": str(result.stages),
        "cb_size": str(result.cb_size),
        "group_size": str(result.group_size),
        "vec_dim": str(result.vec_dim),
        "hadamard_seed": str(result.hadamard_seed),
        "storage_bytes": str(result.storage_bytes),
        "rel_l2": f"{result.rel_l2:.8f}",
        "cosine": f"{result.cosine:.8f}",
    }
    save_file(tensors, str(out_path), metadata=metadata)
    return out_path


def load_m3_layer(
    path: str | Path,
    reconstruct: bool = True,
    device: str | torch.device = "cpu",
) -> M3GPTQResult:
    """Loads a quantized M3-GPTQ layer from a SafeTensors file."""
    in_path = Path(path)
    tensors = load_file(str(in_path), device="cpu")
    with safe_open(str(in_path), framework="pt", device="cpu") as sf:
        meta = sf.metadata() or {}

    cb_stack = tensors["codebooks"]
    shape = (int(meta["shape_0"]), int(meta["shape_1"]))
    result = M3GPTQResult(
        w_hat=None,
        codebooks=[cb_stack[i].contiguous() for i in range(cb_stack.shape[0])],
        packed_indices=tensors["packed_indices"],
        outlier_coords=tensors["outlier_coords"],
        outlier_vals=tensors["outlier_vals"],
        shape=shape,
        stages=int(meta["stages"]),
        cb_size=int(meta["cb_size"]),
        group_size=int(meta["group_size"]),
        vec_dim=int(meta["vec_dim"]),
        hadamard_seed=int(meta["hadamard_seed"]),
        storage_bytes=int(meta["storage_bytes"]),
        rel_l2=float(meta.get("rel_l2", 0.0)),
        cosine=float(meta.get("cosine", 0.0)),
        row_scales=tensors.get("row_scales"),
    )
    if reconstruct:
        result.w_hat = dequantize_m3_weight(result, device=device, dtype=torch.float32)
    return result


@torch.no_grad()
def quantize_linear_layer(
    linear: nn.Linear,
    h_in: torch.Tensor,
    config: M3Config | None = None,
    name: str = "linear",
    r_g: torch.Tensor | None = None,
    use_cache: bool = True,
) -> tuple[M3GPTQResult, Any]:
    """Quantizes a `torch.nn.Linear` layer and returns `(M3GPTQResult, M3Linear)`."""
    from .runtime import M3Linear

    cfg = config or M3Config()
    eff_group = _resolve_group_size(linear.in_features, cfg.group_size, cfg.vec_dim)
    if r_g is None or r_g.shape[0] != eff_group:
        r_g = make_hadamard_block(
            block_dim=eff_group,
            seed=cfg.hadamard_seed,
            device=linear.weight.device,
        )

    result = m3_gptq_quantize(
        w_in=linear.weight.detach(),
        h_in=h_in,
        r_g=r_g,
        name=name,
        outlier_ratio=cfg.outlier_ratio,
        stages=cfg.stages,
        cb_size=cfg.cb_size,
        damp=cfg.damp,
        vec_dim=cfg.vec_dim,
        kmeans_iters=cfg.kmeans_iters,
        hadamard_seed=cfg.hadamard_seed,
        normalize_rows=cfg.normalize_rows,
    )
    m3_mod = M3Linear.from_result(
        result,
        bias=linear.bias.detach() if linear.bias is not None else None,
        use_cache=use_cache,
    ).to(linear.weight.device)
    return result, m3_mod


def _discover_transformer_blocks(model: nn.Module) -> list[tuple[str, nn.Module]]:
    """Finds sequential decoder blocks in common CausalLM architectures."""
    for attr_path in (("model", "layers"), ("transformer", "h"), ("transformer", "layers")):
        cur: Any = model
        for attr in attr_path:
            cur = getattr(cur, attr, None)
            if cur is None:
                break
        if isinstance(cur, nn.ModuleList) and len(cur) > 0:
            prefix = ".".join(attr_path)
            return [(f"{prefix}.{i}", block) for i, block in enumerate(cur)]
    return [("", model)]


def _set_submodule(root: nn.Module, dotted_name: str, new_module: nn.Module) -> None:
    parts = dotted_name.split(".")
    parent = root
    for part in parts[:-1]:
        parent = getattr(parent, part)
    setattr(parent, parts[-1], new_module)


@torch.no_grad()
def _compute_embed_hidden_and_kwargs(
    model: nn.Module,
    calib_tokens: torch.Tensor,
    target_device: torch.device,
    batch_size: int,
) -> tuple[torch.Tensor, dict[str, Any]]:
    """Computes initial decoder-layer input hidden states and shared RoPE/mask kwargs on CPU."""
    backbone = getattr(model, "model", None) or getattr(model, "transformer", None)
    embed = getattr(backbone, "embed_tokens", None) or getattr(backbone, "wte", None)
    if embed is None:
        raise RuntimeError("Streaming offload requires a backbone with embed_tokens/wte.")

    orig_emb_dev = next(embed.parameters()).device
    embed.to(target_device)
    n_seqs, seq_len = calib_tokens.shape
    hidden_chunks: list[torch.Tensor] = []
    for i in range(0, n_seqs, batch_size):
        b = calib_tokens[i : i + batch_size].to(target_device)
        hidden_chunks.append(embed(b).detach().cpu())
    embed.to(orig_emb_dev)
    if target_device.type == "cuda":
        torch.cuda.empty_cache()

    h_all = torch.cat(hidden_chunks, dim=0)
    layer_kwargs: dict[str, Any] = {}
    pos_ids = torch.arange(seq_len, dtype=torch.long).unsqueeze(0)
    layer_kwargs["position_ids"] = pos_ids

    rotary_emb = getattr(backbone, "rotary_emb", None)
    if rotary_emb is not None:
        orig_rot_dev = next((p.device for p in rotary_emb.parameters()), None)
        orig_buf_dev = next((b.device for b in rotary_emb.buffers()), None)
        rotary_emb.to(target_device)
        sample_h = h_all[:1].to(target_device)
        cos, sin = rotary_emb(sample_h, pos_ids.to(target_device))
        layer_kwargs["position_embeddings"] = (cos.detach().cpu(), sin.detach().cpu())
        restore_dev = orig_rot_dev or orig_buf_dev or torch.device("cpu")
        rotary_emb.to(restore_dev)
        if target_device.type == "cuda":
            torch.cuda.empty_cache()

    return h_all, layer_kwargs


@torch.no_grad()
def _run_block_streaming(
    block: nn.Module,
    h_cpu: torch.Tensor,
    layer_kwargs_cpu: dict[str, Any],
    target_device: torch.device,
    batch_size: int,
) -> torch.Tensor:
    """Runs one transformer block across `h_cpu` microbatches on `target_device` and returns CPU output."""
    out_chunks: list[torch.Tensor] = []
    n_seqs = h_cpu.shape[0]
    kw_dev: dict[str, Any] = {}
    if "position_ids" in layer_kwargs_cpu:
        kw_dev["position_ids"] = layer_kwargs_cpu["position_ids"].to(target_device)
    if "position_embeddings" in layer_kwargs_cpu:
        c, s = layer_kwargs_cpu["position_embeddings"]
        kw_dev["position_embeddings"] = (c.to(target_device), s.to(target_device))

    for i in range(0, n_seqs, batch_size):
        hb = h_cpu[i : i + batch_size].to(target_device)
        bs = hb.shape[0]
        call_kw = dict(kw_dev)
        if "position_ids" in call_kw and call_kw["position_ids"].shape[0] != bs:
            call_kw["position_ids"] = call_kw["position_ids"].expand(bs, -1)
        call_kw["use_cache"] = False
        try:
            res = block(hb, **call_kw)
        except TypeError:
            call_kw.pop("position_embeddings", None)
            try:
                res = block(hb, **call_kw)
            except TypeError:
                res = block(hb)
        out_t = res[0] if isinstance(res, tuple) else res
        out_chunks.append(out_t.detach().cpu())
        del hb, res, out_t
    return torch.cat(out_chunks, dim=0)


@torch.no_grad()
def compress_causal_lm(
    model: nn.Module,
    calib_tokens: torch.Tensor,
    config: M3Config | None = None,
    skip_modules: tuple[str, ...] = ("lm_head",),
    replace_modules: bool = True,
    use_cache: bool = True,
    batch_size: int = 1,
    device: str | torch.device | None = None,
    offload: bool | str = "auto",
) -> dict[str, Any]:
    """Compresses all linear layers of a CausalLM layer-by-layer using M3-GPTQ.

    When `offload=True` (or `offload="auto"` on >= 4.5 GiB models / CPU-loaded models
    targeted at CUDA), streams one transformer block at a time to `device` so 7B+
    models fit inside an 8 GB VRAM envelope.
    """
    cfg = config or M3Config()
    target_device = torch.device(device) if device is not None else next(model.parameters()).device
    model.eval()
    prev_use_cache = getattr(getattr(model, "config", None), "use_cache", None)
    if hasattr(model, "config") and hasattr(model.config, "use_cache"):
        model.config.use_cache = False

    total_param_bytes = sum(p.numel() * p.element_size() for p in model.parameters())
    first_param_dev = next(model.parameters()).device
    if offload == "auto":
        use_streaming = (
            target_device.type == "cuda"
            and (total_param_bytes >= int(4.5 * (1024**3)) or first_param_dev.type == "cpu")
        )
    else:
        use_streaming = bool(offload)

    blocks = _discover_transformer_blocks(model)
    r_cache: dict[int, torch.Tensor] = {}

    total_storage_bytes = 0
    total_params = 0
    rels: list[float] = []
    coss: list[float] = []
    layer_stats: dict[str, dict[str, float | int | list[int]]] = {}

    try:
        h_stream_cpu: torch.Tensor | None = None
        layer_kw_cpu: dict[str, Any] = {}
        if use_streaming:
            h_stream_cpu, layer_kw_cpu = _compute_embed_hidden_and_kwargs(
                model, calib_tokens, target_device, batch_size=batch_size
            )

        for block_prefix, block in blocks:
            orig_block_dev = next((p.device for p in block.parameters()), target_device)
            if use_streaming:
                block.to(target_device)

            linear_entries: list[tuple[str, nn.Linear]] = []
            for mod_name, mod in block.named_modules():
                if not isinstance(mod, nn.Linear):
                    continue
                full_name = f"{block_prefix}.{mod_name}" if block_prefix else mod_name
                if any(skip in full_name for skip in skip_modules):
                    continue
                linear_entries.append((mod_name, mod))

            if not linear_entries:
                if use_streaming and h_stream_cpu is not None:
                    h_stream_cpu = _run_block_streaming(
                        block, h_stream_cpu, layer_kw_cpu, target_device, batch_size=batch_size
                    )
                    block.to(orig_block_dev)
                continue

            hessians: dict[str, list[Any]] = {}
            hooks = []
            for mod_name, mod in linear_entries:
                hessians[mod_name] = [
                    torch.zeros((mod.in_features, mod.in_features), dtype=torch.float32, device=target_device),
                    0,
                ]

                def _make_hook(key: str):
                    def _hook(_mod: nn.Module, inp: tuple[torch.Tensor, ...], _out: Any) -> None:
                        x = inp[0].reshape(-1, inp[0].shape[-1]).to(device=target_device, dtype=torch.float32)
                        hessians[key][0].addmm_(x.t(), x)
                        hessians[key][1] += x.shape[0]

                    return _hook

                hooks.append(mod.register_forward_hook(_make_hook(mod_name)))

            if use_streaming and h_stream_cpu is not None:
                h_next_cpu = _run_block_streaming(
                    block, h_stream_cpu, layer_kw_cpu, target_device, batch_size=batch_size
                )
            else:
                h_next_cpu = None
                for i in range(0, calib_tokens.shape[0], batch_size):
                    batch = calib_tokens[i : i + batch_size].to(target_device)
                    model(batch, use_cache=False) if hasattr(model, "config") else model(batch)

            for h in hooks:
                h.remove()

            for mod_name, mod in linear_entries:
                full_name = f"{block_prefix}.{mod_name}" if block_prefix else mod_name
                h_sum, count = hessians.pop(mod_name)
                h_mat = h_sum / max(1, count)
                eff_g = _resolve_group_size(mod.in_features, cfg.group_size, cfg.vec_dim)
                if eff_g not in r_cache:
                    r_cache[eff_g] = make_hadamard_block(
                        block_dim=eff_g,
                        seed=cfg.hadamard_seed,
                        device=target_device,
                    )

                w_orig = mod.weight.detach().to(target_device)
                res = m3_gptq_quantize(
                    w_in=w_orig,
                    h_in=h_mat,
                    r_g=r_cache[eff_g],
                    name=full_name,
                    outlier_ratio=cfg.outlier_ratio,
                    stages=cfg.stages,
                    cb_size=cfg.cb_size,
                    damp=cfg.damp,
                    vec_dim=cfg.vec_dim,
                    kmeans_iters=cfg.kmeans_iters,
                    hadamard_seed=cfg.hadamard_seed,
                    normalize_rows=cfg.normalize_rows,
                )

                if replace_modules:
                    from .runtime import M3Linear

                    m3_layer = M3Linear.from_result(
                        res,
                        bias=mod.bias.detach() if mod.bias is not None else None,
                        use_cache=use_cache,
                    ).to(orig_block_dev if use_streaming else target_device)
                    _set_submodule(block, mod_name, m3_layer)
                else:
                    assert res.w_hat is not None
                    mod.weight.copy_(res.w_hat.to(dtype=mod.weight.dtype, device=mod.weight.device))

                total_storage_bytes += res.storage_bytes
                total_params += w_orig.numel()
                rels.append(res.rel_l2)
                coss.append(res.cosine)
                layer_stats[full_name] = {
                    "shape": list(res.shape),
                    "storage_bytes": res.storage_bytes,
                    "effective_bpw": round(res.effective_bpw, 4),
                    "rel_l2": round(res.rel_l2, 6),
                    "cosine": round(res.cosine, 6),
                }
                del h_mat, w_orig, res

            if use_streaming:
                block.to(orig_block_dev)
                h_stream_cpu = h_next_cpu
            if target_device.type == "cuda":
                torch.cuda.empty_cache()
    finally:
        if prev_use_cache is not None and hasattr(model, "config"):
            model.config.use_cache = prev_use_cache

    return {
        "effective_bpw": (total_storage_bytes * 8.0 / total_params) if total_params > 0 else 0.0,
        "mean_rel_l2": (sum(rels) / len(rels)) if rels else 0.0,
        "mean_cosine": (sum(coss) / len(coss)) if coss else 0.0,
        "total_storage_bytes": total_storage_bytes,
        "total_params": total_params,
        "num_layers": len(rels),
        "layer_stats": layer_stats,
    }


def save_m3_model(model: nn.Module, output_dir: str | Path, config: M3Config | None = None) -> Path:
    """Saves an M3-compressed HuggingFace model directory (manifest + SafeTensors)."""
    from .runtime import M3Linear

    out_dir = Path(output_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    if hasattr(model, "config") and hasattr(model.config, "save_pretrained"):
        model.config.save_pretrained(str(out_dir))

    m3_tensors: dict[str, torch.Tensor] = {}
    m3_meta: dict[str, dict[str, Any]] = {}
    non_m3_tensors: dict[str, torch.Tensor] = {}

    m3_prefixes: list[str] = []
    for name, mod in model.named_modules():
        if isinstance(mod, M3Linear):
            m3_prefixes.append(name)
            m3_tensors[f"{name}.codebooks"] = mod.codebooks.detach().cpu().half().contiguous()
            m3_tensors[f"{name}.packed_indices"] = mod.packed_indices.detach().cpu().contiguous()
            m3_tensors[f"{name}.outlier_coords"] = mod.outlier_coords.detach().cpu().contiguous()
            m3_tensors[f"{name}.outlier_vals"] = mod.outlier_vals.detach().cpu().half().contiguous()
            if mod.row_scales is not None:
                m3_tensors[f"{name}.row_scales"] = mod.row_scales.detach().cpu().half().contiguous()
            if mod.bias is not None:
                m3_tensors[f"{name}.bias"] = mod.bias.detach().cpu().contiguous()
            m3_meta[name] = {
                "in_features": mod.in_features,
                "out_features": mod.out_features,
                "stages": mod.stages,
                "cb_size": mod.cb_size,
                "group_size": mod.group_size,
                "vec_dim": mod.vec_dim,
                "hadamard_seed": mod.hadamard_seed,
                "has_bias": mod.bias is not None,
                "has_row_scales": mod.row_scales is not None,
            }

    seen_ptrs: set[tuple[int, tuple[int, ...], str]] = set()
    for k, v in model.state_dict().items():
        if any(k.startswith(f"{pref}.") for pref in m3_prefixes):
            continue
        sig = (int(v.data_ptr()), tuple(v.shape), str(v.dtype))
        if sig in seen_ptrs:
            continue
        seen_ptrs.add(sig)
        non_m3_tensors[k] = v.detach().cpu().contiguous()

    save_file(m3_tensors, str(out_dir / "m3_layers.safetensors"))
    save_file(non_m3_tensors, str(out_dir / "non_quantized.safetensors"))

    manifest = {
        "format": "zaqeris_m3_gptq_model_v1",
        "config": (
            {
                "stages": config.stages,
                "cb_size": config.cb_size,
                "outlier_ratio": config.outlier_ratio,
                "group_size": config.group_size,
                "vec_dim": config.vec_dim,
                "damp": config.damp,
                "kmeans_iters": config.kmeans_iters,
                "hadamard_seed": config.hadamard_seed,
                "normalize_rows": config.normalize_rows,
            }
            if config is not None
            else None
        ),
        "layers": m3_meta,
    }
    (out_dir / "m3_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    return out_dir


def load_m3_model(
    model_dir: str | Path,
    device: str | torch.device = "cpu",
    dtype: torch.dtype = torch.bfloat16,
    use_cache: bool = True,
) -> nn.Module:
    """Loads an M3-compressed HuggingFace CausalLM saved by `save_m3_model`."""
    from transformers import AutoConfig, AutoModelForCausalLM
    from .runtime import M3Linear

    in_dir = Path(model_dir)
    manifest = json.loads((in_dir / "m3_manifest.json").read_text(encoding="utf-8"))
    hf_config = AutoConfig.from_pretrained(str(in_dir))
    try:
        model = AutoModelForCausalLM.from_config(hf_config, dtype=dtype)
    except TypeError:
        model = AutoModelForCausalLM.from_config(hf_config, torch_dtype=dtype)

    non_m3 = load_file(str(in_dir / "non_quantized.safetensors"), device="cpu")
    model.load_state_dict(non_m3, strict=False)
    if getattr(hf_config, "tie_word_embeddings", False) and hasattr(model, "tie_weights"):
        model.tie_weights()

    m3_tensors = load_file(str(in_dir / "m3_layers.safetensors"), device="cpu")
    for layer_name, meta in manifest["layers"].items():
        bias = m3_tensors[f"{layer_name}.bias"] if meta.get("has_bias", False) else None
        row_scales = m3_tensors[f"{layer_name}.row_scales"] if meta.get("has_row_scales", False) else None
        m3_mod = M3Linear(
            in_features=int(meta["in_features"]),
            out_features=int(meta["out_features"]),
            codebooks=m3_tensors[f"{layer_name}.codebooks"],
            packed_indices=m3_tensors[f"{layer_name}.packed_indices"],
            outlier_coords=m3_tensors[f"{layer_name}.outlier_coords"],
            outlier_vals=m3_tensors[f"{layer_name}.outlier_vals"],
            stages=int(meta["stages"]),
            cb_size=int(meta["cb_size"]),
            group_size=int(meta["group_size"]),
            vec_dim=int(meta["vec_dim"]),
            hadamard_seed=int(meta["hadamard_seed"]),
            bias=bias,
            use_cache=use_cache,
            row_scales=row_scales,
        )
        _set_submodule(model, layer_name, m3_mod)

    return model.to(device).eval()
