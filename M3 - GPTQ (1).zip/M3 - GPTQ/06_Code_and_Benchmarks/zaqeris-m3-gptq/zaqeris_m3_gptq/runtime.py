"""Runtime inference wrapper and resident-weight cache for ZAQERIS M3-GPTQ.

Provides `M3Linear`, a drop-in `torch.nn.Module` replacement for `torch.nn.Linear`
that stores compact multi-stage RVQ codebooks, bit-packed indices, and sparse
OBQ outliers, reconstructing dense FP16/BF16 weights on demand with an optional
two-pool resident cache (`ZAQERIS_M3_CACHE_MIB`).
"""

from __future__ import annotations

import itertools
import math
import os
from collections import OrderedDict
from dataclasses import dataclass
from typing import TYPE_CHECKING, Any

import torch
import torch.nn as nn
import torch.nn.functional as F

from .core import (
    make_hadamard_block,
    reconstruct_m3_matrix,
    unpack_indices,
)

if TYPE_CHECKING:
    from .core import M3GPTQResult

# Standard attention/MLP dense projections stay under 16M elements; larger
# matrices (e.g., wide FFN experts or vocabulary heads) route to the cold pool.
HOT_MAX_ELEMENTS = 16_777_216
_CHUNK_ROWS = 16384
_CACHE: ResidentWeightCache | None = None
_HADAMARD_CACHE: dict[tuple[str, int, int], torch.Tensor] = {}
_INSTANCE_COUNTER = itertools.count(1)


@dataclass
class CacheStats:
    """Hit/miss counters for `ResidentWeightCache`."""

    hits: int = 0
    misses: int = 0
    stores: int = 0
    rejected: int = 0


class ResidentWeightCache:
    """Two-pool first-fit resident cache for reconstructed M3 weight matrices."""

    def __init__(
        self,
        budget_bytes: int,
        hot_fraction: float = 0.85,
        max_entry_bytes: int | None = None,
    ) -> None:
        if budget_bytes < 0:
            raise ValueError("budget_bytes must be >= 0")
        if not 0.0 < hot_fraction < 1.0:
            raise ValueError("hot_fraction must be between 0 and 1")
        self.budget_bytes = int(budget_bytes)
        self.hot_budget = int(self.budget_bytes * hot_fraction)
        self.cold_budget = self.budget_bytes - self.hot_budget
        self.max_entry_bytes = None if max_entry_bytes is None else int(max_entry_bytes)
        self.hot: OrderedDict[tuple[Any, ...], torch.Tensor] = OrderedDict()
        self.cold: OrderedDict[tuple[Any, ...], torch.Tensor] = OrderedDict()
        self.hot_used = 0
        self.cold_used = 0
        self.stats = CacheStats()

    def get(self, key: tuple[Any, ...]) -> torch.Tensor | None:
        """Retrieves a cached dense matrix if present."""
        for pool in (self.hot, self.cold):
            tensor = pool.get(key)
            if tensor is not None:
                pool.move_to_end(key)
                self.stats.hits += 1
                return tensor
        self.stats.misses += 1
        return None

    def put(self, key: tuple[Any, ...], tensor: torch.Tensor, hot: bool) -> bool:
        """Stores a reconstructed matrix using first-fit admission."""
        nbytes = int(tensor.nbytes)
        budget = self.hot_budget if hot else self.cold_budget
        if (
            self.budget_bytes <= 0
            or nbytes <= 0
            or nbytes > budget
            or (self.max_entry_bytes is not None and nbytes > self.max_entry_bytes)
        ):
            self.stats.rejected += 1
            return False

        pool = self.hot if hot else self.cold
        used = self.hot_used if hot else self.cold_used
        existing = pool.get(key)
        if existing is not None:
            used -= int(existing.nbytes)

        if used + nbytes > budget:
            self.stats.rejected += 1
            return False

        pool[key] = tensor
        pool.move_to_end(key)
        if hot:
            self.hot_used = used + nbytes
        else:
            self.cold_used = used + nbytes
        self.stats.stores += 1
        return True

    def snapshot(self) -> dict[str, int | float]:
        """Returns memory utilization and hit/miss statistics."""
        mib = 1024 * 1024
        return {
            "budget_mib": round(self.budget_bytes / mib, 3),
            "hot_used_mib": round(self.hot_used / mib, 3),
            "cold_used_mib": round(self.cold_used / mib, 3),
            "hot_entries": len(self.hot),
            "cold_entries": len(self.cold),
            "hits": self.stats.hits,
            "misses": self.stats.misses,
            "stores": self.stats.stores,
            "rejected": self.stats.rejected,
        }


def _env_mib(name: str, default_mib: float) -> int:
    raw = os.environ.get(name)
    mib = default_mib if raw is None or raw.strip() == "" else float(raw)
    if mib < 0:
        raise ValueError(f"{name} must be >= 0")
    return int(mib * 1024 * 1024)


def get_cache() -> ResidentWeightCache:
    """Returns the process-wide `ResidentWeightCache` singleton."""
    global _CACHE
    if _CACHE is None:
        _CACHE = ResidentWeightCache(
            budget_bytes=_env_mib("ZAQERIS_M3_CACHE_MIB", 384.0),
            max_entry_bytes=_env_mib("ZAQERIS_M3_CACHE_MAX_ENTRY_MIB", 96.0),
        )
    return _CACHE


def reset_cache(
    budget_mib: float | None = None,
    max_entry_mib: float | None = None,
) -> ResidentWeightCache:
    """Clears and reinitializes the global `ResidentWeightCache`."""
    global _CACHE
    if budget_mib is None and max_entry_mib is None:
        _CACHE = None
        return get_cache()
    budget_bytes = (
        int(budget_mib * 1024 * 1024)
        if budget_mib is not None
        else _env_mib("ZAQERIS_M3_CACHE_MIB", 384.0)
    )
    max_bytes = (
        int(max_entry_mib * 1024 * 1024)
        if max_entry_mib is not None
        else _env_mib("ZAQERIS_M3_CACHE_MAX_ENTRY_MIB", 96.0)
    )
    _CACHE = ResidentWeightCache(budget_bytes=budget_bytes, max_entry_bytes=max_bytes)
    return _CACHE


def is_hot_matrix(out_features: int, in_features: int) -> bool:
    """Returns True if the matrix fits in the hot attention/dense pool."""
    return int(out_features) * int(in_features) <= HOT_MAX_ELEMENTS


def _get_hadamard(device: torch.device, group_size: int, seed: int) -> torch.Tensor:
    key = (str(device), group_size, seed)
    r_g = _HADAMARD_CACHE.get(key)
    if r_g is None:
        r_g = make_hadamard_block(block_dim=group_size, seed=seed, device=device)
        _HADAMARD_CACHE[key] = r_g
    return r_g


class M3Linear(nn.Module):
    """Quantized linear layer backed by ZAQERIS M3-GPTQ codebooks and sparse outliers."""

    def __init__(
        self,
        in_features: int,
        out_features: int,
        codebooks: torch.Tensor | list[torch.Tensor],
        packed_indices: torch.Tensor,
        outlier_coords: torch.Tensor,
        outlier_vals: torch.Tensor,
        stages: int,
        cb_size: int,
        group_size: int = 128,
        vec_dim: int = 8,
        hadamard_seed: int = 1234,
        bias: torch.Tensor | None = None,
        use_cache: bool = True,
        row_scales: torch.Tensor | None = None,
    ) -> None:
        super().__init__()
        self.in_features = int(in_features)
        self.out_features = int(out_features)
        self.stages = int(stages)
        self.cb_size = int(cb_size)
        self.group_size = int(group_size)
        self.vec_dim = int(vec_dim)
        self.hadamard_seed = int(hadamard_seed)
        self.use_cache = bool(use_cache)
        self._instance_id = next(_INSTANCE_COUNTER)

        if isinstance(codebooks, list):
            cb_tensor = torch.stack([c.half() for c in codebooks], dim=0)
        else:
            cb_tensor = codebooks.half()

        self.register_buffer("codebooks", cb_tensor.contiguous())
        self.register_buffer("packed_indices", packed_indices.to(torch.uint8).contiguous())
        self.register_buffer("outlier_coords", outlier_coords.contiguous())
        self.register_buffer("outlier_vals", outlier_vals.half().contiguous())
        if row_scales is not None:
            self.register_buffer("row_scales", row_scales.detach().half().to(cb_tensor.device).contiguous())
        else:
            self.register_buffer("row_scales", None)
        if bias is not None:
            self.register_buffer("bias", bias.detach().to(cb_tensor.device).contiguous())
        else:
            self.register_buffer("bias", None)

    @classmethod
    def from_result(
        cls,
        result: M3GPTQResult,
        bias: torch.Tensor | None = None,
        use_cache: bool = True,
    ) -> M3Linear:
        """Constructs an `M3Linear` module from an `M3GPTQResult`."""
        out_features, in_features = result.shape
        return cls(
            in_features=in_features,
            out_features=out_features,
            codebooks=result.codebooks,
            packed_indices=result.packed_indices,
            outlier_coords=result.outlier_coords,
            outlier_vals=result.outlier_vals,
            stages=result.stages,
            cb_size=result.cb_size,
            group_size=result.group_size,
            vec_dim=result.vec_dim,
            hadamard_seed=result.hadamard_seed,
            bias=bias,
            use_cache=use_cache,
            row_scales=result.row_scales,
        )

    @property
    def idx_bits(self) -> int:
        return max(1, int(math.ceil(math.log2(self.cb_size))))

    @property
    def storage_bytes(self) -> int:
        coord_bytes = self.outlier_coords.element_size() * 2 if self.outlier_coords.numel() > 0 else 4
        bias_bytes = self.bias.nbytes if self.bias is not None else 0
        scale_bytes = self.row_scales.nbytes if self.row_scales is not None else 0
        return (
            int(self.codebooks.nbytes)
            + int(self.packed_indices.nbytes)
            + int(self.outlier_vals.numel()) * (2 + coord_bytes)
            + bias_bytes
            + scale_bytes
            + 12
        )

    @property
    def effective_bpw(self) -> float:
        total = self.out_features * self.in_features
        return (self.storage_bytes * 8.0 / total) if total > 0 else 0.0

    def _would_admit(self, cache: ResidentWeightCache, dtype: torch.dtype) -> bool:
        elem_size = 2 if dtype in (torch.float16, torch.bfloat16) else 4
        nbytes = self.out_features * self.in_features * elem_size
        hot = is_hot_matrix(self.out_features, self.in_features)
        budget = cache.hot_budget if hot else cache.cold_budget
        if cache.budget_bytes <= 0 or nbytes > budget:
            return False
        if cache.max_entry_bytes is not None and nbytes > cache.max_entry_bytes:
            return False
        return True

    @torch.no_grad()
    def reconstruct_weight(self, dtype: torch.dtype = torch.float16) -> torch.Tensor:
        """Reconstructs the dense `(out_features, in_features)` weight matrix."""
        device = self.codebooks.device
        r_g = _get_hadamard(device, self.group_size, self.hadamard_seed)
        return reconstruct_m3_matrix(
            codebooks=self.codebooks,
            packed_indices=self.packed_indices,
            outlier_coords=self.outlier_coords,
            outlier_vals=self.outlier_vals,
            shape=(self.out_features, self.in_features),
            group_size=self.group_size,
            vec_dim=self.vec_dim,
            hadamard_seed=self.hadamard_seed,
            device=device,
            dtype=dtype,
            r_g=r_g,
            row_scales=self.row_scales,
        )

    def reconstruct_full(self, dtype: torch.dtype = torch.float16) -> torch.Tensor:
        """Alias for `reconstruct_weight`."""
        return self.reconstruct_weight(dtype=dtype)

    @torch.no_grad()
    def _chunked_linear(self, x: torch.Tensor, compute_dtype: torch.dtype) -> torch.Tensor:
        """Row-chunked reconstruction + GEMM for very tall projections."""
        device = self.codebooks.device
        vecs_per_row = self.in_features // self.vec_dim
        num_vecs = self.out_features * vecs_per_row
        idx = unpack_indices(self.packed_indices, num_vecs, self.idx_bits)
        cbs = self.codebooks.float()
        r_g_t = _get_hadamard(device, self.group_size, self.hadamard_seed).t()

        has_outliers = self.outlier_vals.numel() > 0
        out_rows = self.outlier_coords[:, 0].long() if has_outliers else None
        out_cols = self.outlier_coords[:, 1].long() if has_outliers else None
        out_vals = self.outlier_vals.float() if has_outliers else None

        outputs: list[torch.Tensor] = []
        for r_start in range(0, self.out_features, _CHUNK_ROWS):
            r_end = min(r_start + _CHUNK_ROWS, self.out_features)
            n_rows = r_end - r_start
            v_start = r_start * vecs_per_row
            v_end = r_end * vecs_per_row

            w_vecs = torch.zeros((v_end - v_start, self.vec_dim), device=device, dtype=torch.float32)
            for s in range(self.stages):
                w_vecs.add_(cbs[s][idx[s, v_start:v_end]])
            w_rot = w_vecs.view(n_rows, self.in_features)

            if has_outliers and out_rows is not None and out_cols is not None and out_vals is not None:
                mask = (out_rows >= r_start) & (out_rows < r_end)
                if bool(mask.any()):
                    w_rot[out_rows[mask] - r_start, out_cols[mask]] = out_vals[mask]

            w_chunk = (
                w_rot.view(n_rows, self.in_features // self.group_size, self.group_size) @ r_g_t
            ).reshape(n_rows, self.in_features)
            if self.row_scales is not None:
                w_chunk = w_chunk * self.row_scales[r_start:r_end].to(device=device, dtype=torch.float32).unsqueeze(1)
            w_chunk = w_chunk.to(compute_dtype)
            b_chunk = self.bias[r_start:r_end].to(compute_dtype) if self.bias is not None else None
            outputs.append(F.linear(x, w_chunk, b_chunk))

        return torch.cat(outputs, dim=-1)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """Applies the quantized linear transformation to `x`."""
        target = self.codebooks.device
        if x.device != target:
            x = x.to(target)
        compute_dtype = x.dtype if x.is_floating_point() else torch.float16

        if self.use_cache:
            cache = get_cache()
            key = (self._instance_id, str(target), str(compute_dtype))
            dense = cache.get(key)
            if dense is None and self.out_features > _CHUNK_ROWS and not self._would_admit(cache, compute_dtype):
                return self._chunked_linear(x, compute_dtype)
            if dense is None:
                dense = self.reconstruct_weight(dtype=compute_dtype)
                cache.put(key, dense, hot=is_hot_matrix(self.out_features, self.in_features))
        else:
            if self.out_features > _CHUNK_ROWS:
                return self._chunked_linear(x, compute_dtype)
            dense = self.reconstruct_weight(dtype=compute_dtype)

        bias = self.bias.to(device=target, dtype=compute_dtype) if self.bias is not None else None
        return F.linear(x, dense, bias)

    def extra_repr(self) -> str:
        return (
            f"in_features={self.in_features}, out_features={self.out_features}, "
            f"stages={self.stages}, cb_size={self.cb_size}, "
            f"bpw={self.effective_bpw:.3f}, bias={self.bias is not None}"
        )
