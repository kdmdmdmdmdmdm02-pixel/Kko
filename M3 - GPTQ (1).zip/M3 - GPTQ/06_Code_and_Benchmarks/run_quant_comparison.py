"""Fair, Scientific Multi-Method Quantization Comparison Suite.

Compares on identical WikiText-2 (test), MMLU (100), ARC-Challenge (100), VRAM, and tok/s:
  1. BF16 Baseline (16.0 bpw)
  2. BitsAndBytes NF4 (4-bit NormalFloat + double quant, ~4.5 bpw)
  3. BitsAndBytes INT8 (LLM.int8(), ~8.0 bpw, when VRAM permits)
  4. Scalar GPTQ 4-bit (g=128 asymmetric + Cholesky error feedback, ~4.25 bpw)
  5. Scalar GPTQ 3-bit (g=128 asymmetric + Cholesky error feedback, ~3.25 bpw — matched BPW to M3 3x8b)
  6. ZAQERIS M3-GPTQ 3x8b (norm_rows=True, ~3.26 bpw)
  7. ZAQERIS M3-GPTQ 3x7b (norm_rows=True, ~2.76 bpw)
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import time
from pathlib import Path
from typing import Any

import torch
import torch.nn as nn
from transformers import AutoModelForCausalLM, AutoTokenizer, BitsAndBytesConfig

from zaqeris_m3_gptq.cli import evaluate_perplexity, load_token_splits
from zaqeris_m3_gptq.core import _compute_embed_hidden_and_kwargs, _discover_transformer_blocks, _run_block_streaming

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))
from run_7b_m3_suite import eval_arc_subset, eval_mmlu_subset, eval_streaming_all, measure_decode_speed


@torch.no_grad()
def _gptq_scalar_quantize(w_in: torch.Tensor, h_in: torch.Tensor, bits: int = 3, group_size: int = 128, damp: float = 0.01) -> tuple[torch.Tensor, int]:
    """Standard per-group asymmetric scalar GPTQ with Block-8 Cholesky error feedback."""
    w = w_in.float().clone()
    m, n = w.shape
    h = h_in.to(device=w.device, dtype=torch.float32).clone()
    dead = torch.diag(h) == 0
    h[dead, dead] = 1.0
    w[:, dead] = 0.0

    diag_mean = torch.diag(h).mean().clamp_min(1e-8)
    h_inv = None
    for sc in (1.0, 10.0, 100.0, 1000.0):
        h_damped = None
        chol = None
        inv_h = None
        try:
            h_damped = h.clone()
            h_damped.diagonal().add_((damp * sc) * diag_mean)
            chol = torch.linalg.cholesky(h_damped)
            del h_damped
            h_damped = None
            inv_h = torch.cholesky_inverse(chol)
            del chol
            chol = None
            h_inv = torch.linalg.cholesky(inv_h, upper=True)
            del inv_h
            inv_h = None
            break
        except torch.linalg.LinAlgError:
            del h_damped, chol, inv_h
            continue
    del h
    if device_is_cuda := (w.device.type == "cuda"):
        torch.cuda.empty_cache()
    if h_inv is None:
        raise RuntimeError("Scalar GPTQ Hessian Cholesky failed")

    qmax = (1 << bits) - 1
    blk_w = 8
    nb = n // blk_w
    idx_b = torch.arange(nb, device=w.device)
    inv_diag = torch.linalg.inv(h_inv.view(nb, blk_w, nb, blk_w)[idx_b, :, idx_b, :])

    q_out = torch.zeros_like(w)
    w_cur = w.clone()
    scale_cache: dict[int, tuple[torch.Tensor, torch.Tensor]] = {}

    for b_idx in range(nb):
        g0, g1 = b_idx * blk_w, (b_idx + 1) * blk_w
        grp_id = g0 // group_size
        if grp_id not in scale_cache:
            gs = grp_id * group_size
            ge = min(n, gs + group_size)
            sub = w_cur[:, gs:ge]
            mn = sub.amin(dim=1, keepdim=True)
            mx = sub.amax(dim=1, keepdim=True)
            scale = ((mx - mn) / qmax).clamp_min(1e-8)
            zero = torch.round(-mn / scale).clamp(0, qmax)
            scale_cache[grp_id] = (scale, zero)
        scale, zero = scale_cache[grp_id]

        blk_orig = w_cur[:, g0:g1]
        q_int = torch.round(blk_orig / scale + zero).clamp(0, qmax)
        q_blk = (q_int - zero) * scale
        q_out[:, g0:g1] = q_blk
        if g1 < n:
            err = (blk_orig - q_blk) @ inv_diag[b_idx]
            w_cur[:, g1:] -= err @ h_inv[g0:g1, g1:]

    # Storage: bits/weight + (2x FP16 scale+zero per group of 128)
    n_groups = m * (n // group_size)
    storage_bytes = (m * n * bits + 7) // 8 + n_groups * 4
    return q_out, storage_bytes


@torch.no_grad()
def run_scalar_gptq_eval(
    model_id: str,
    calib: torch.Tensor,
    ev: torch.Tensor,
    tokenizer: Any,
    device: torch.device,
    bits: int,
    base_ppl: float,
) -> dict[str, Any]:
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    try:
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()

    t0 = time.time()
    h_cpu, kw_cpu = _compute_embed_hidden_and_kwargs(model, calib, device, batch_size=1)
    total_bytes = 0
    total_params = 0
    rels, coss = [], []

    for blk_pref, block in _discover_transformer_blocks(model):
        block.to(device)
        linears = [(n, m) for n, m in block.named_modules() if isinstance(m, nn.Linear)]
        hess = {n: [torch.zeros((m.in_features, m.in_features), dtype=torch.float32, device=device), 0] for n, m in linears}
        hooks = []
        for n, m in linears:
            def _mk(k):
                def _hk(_mod, inp, _out):
                    x = inp[0].reshape(-1, inp[0].shape[-1]).to(device=device, dtype=torch.float32)
                    hess[k][0].addmm_(x.t(), x)
                    hess[k][1] += x.shape[0]
                return _hk
            hooks.append(m.register_forward_hook(_mk(n)))
        h_next = _run_block_streaming(block, h_cpu, kw_cpu, device, batch_size=1)
        for hk in hooks:
            hk.remove()
        block.to("cpu")
        for k in hess:
            hess[k][0] = hess[k][0].cpu()
        if device.type == "cuda":
            torch.cuda.empty_cache()
        for n, m in linears:
            hs, cnt = hess.pop(n)
            hm = hs.to(device) / max(1, cnt)
            del hs
            w0 = m.weight.detach().to(device)
            q_w, sb = _gptq_scalar_quantize(w0, hm, bits=bits, group_size=128)
            rels.append(((q_w - w0.float()).norm() / w0.float().norm().clamp_min(1e-12)).item())
            coss.append(torch.nn.functional.cosine_similarity(q_w.reshape(1, -1), w0.float().reshape(1, -1)).item())
            m.weight.copy_(q_w.to(dtype=m.weight.dtype, device=m.weight.device))
            total_bytes += sb
            total_params += w0.numel()
            del hm, w0, q_w
            if device.type == "cuda":
                torch.cuda.empty_cache()
        h_cpu = h_next

    comp_s = round(time.time() - t0, 1)
    q_ppl, q_mmlu, q_arc = eval_streaming_all(model, ev, tokenizer, device, limit=100)
    peak_vram = round(torch.cuda.max_memory_allocated() / (1024**3), 3) if device.type == "cuda" else 0.0

    del model, h_cpu
    gc.collect()
    torch.cuda.empty_cache()
    return {
        "method": f"GPTQ Scalar {bits}-bit (g=128)",
        "linear_bpw": round(total_bytes * 8.0 / total_params, 4),
        "mean_cosine": round(sum(coss) / len(coss), 5),
        "mean_rel_l2": round(sum(rels) / len(rels), 5),
        "compress_seconds": comp_s,
        "wikitext2_ppl": round(q_ppl, 4),
        "ppl_ratio_vs_bf16": round(q_ppl / base_ppl, 4),
        "mmlu_100": q_mmlu,
        "arc_100": q_arc,
        "peak_vram_gib": peak_vram,
        "decode_tokens_per_sec": None,
        "note": "Simulated fake-quant BF16 dequantized weights; speed reflects streaming BF16",
    }


@torch.no_grad()
def run_bnb_eval(
    model_id: str,
    mode: str,
    ev: torch.Tensor,
    tokenizer: Any,
    device: torch.device,
    base_ppl: float,
) -> dict[str, Any]:
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    try:
        if mode == "nf4":
            qcfg = BitsAndBytesConfig(
                load_in_4bit=True,
                bnb_4bit_quant_type="nf4",
                bnb_4bit_use_double_quant=True,
                bnb_4bit_compute_dtype=torch.bfloat16,
            )
            label = "BitsAndBytes NF4 (4-bit + double quant)"
            est_bpw = 4.25
        elif mode == "int8":
            qcfg = BitsAndBytesConfig(load_in_8bit=True)
            label = "BitsAndBytes LLM.int8() (8-bit)"
            est_bpw = 8.0
        else:
            raise ValueError(mode)

        model = AutoModelForCausalLM.from_pretrained(
            model_id,
            quantization_config=qcfg,
            device_map={"": 0},
        ).eval()
        loaded_vram = round(torch.cuda.memory_allocated() / (1024**3), 3)
        t0 = time.time()
        q_ppl = evaluate_perplexity(model, ev, device=device, batch_size=1)
        ev_s = round(time.time() - t0, 1)
        q_mmlu = eval_mmlu_subset(model, tokenizer, device, limit=100)
        q_arc = eval_arc_subset(model, tokenizer, device, limit=100)
        tok_s = measure_decode_speed(model, tokenizer, device, max_new_tokens=48)
        peak_vram = round(torch.cuda.max_memory_allocated() / (1024**3), 3)
        del model
        gc.collect()
        torch.cuda.empty_cache()
        return {
            "method": label,
            "linear_bpw": est_bpw,
            "loaded_vram_gib": loaded_vram,
            "eval_peak_vram_gib": peak_vram,
            "wikitext2_ppl": round(q_ppl, 4),
            "ppl_ratio_vs_bf16": round(q_ppl / base_ppl, 4),
            "ppl_eval_seconds": ev_s,
            "mmlu_100": q_mmlu,
            "arc_100": q_arc,
            "decode_tokens_per_sec": tok_s,
        }
    except Exception as exc:
        gc.collect()
        if device.type == "cuda":
            torch.cuda.empty_cache()
        return {"method": f"BitsAndBytes {mode}", "error": f"{type(exc).__name__}: {str(exc)[:220]}"}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--m3-json", default=None, help="Optional existing M3 JSON from run_7b_m3_suite.py to merge")
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--calib-tokens", type=int, default=32768)
    parser.add_argument("--eval-tokens", type=int, default=32768)
    parser.add_argument("--include-int8", action="store_true")
    parser.add_argument("--fast", action="store_true", help="Run focused 4-method comparison (BF16, M3-GPTQ 3x8b, BnB NF4, GPTQ 3-bit)")
    args = parser.parse_args()

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained(args.model)
    calib, ev = load_token_splits(
        tokenizer,
        calib_tokens=args.calib_tokens,
        eval_tokens=args.eval_tokens,
        seq_len=1024,
        wikitext=True,
    )

    if args.m3_json and Path(args.m3_json).is_file():
        report = json.loads(Path(args.m3_json).read_text(encoding="utf-8"))
        base_ppl = float(report["bf16_baseline"]["wikitext2_ppl"])
    else:
        from run_7b_m3_suite import run_suite
        presets = [("M3-GPTQ 3x8b (norm_rows=True)", "3x8b", True)] if args.fast else [
            ("M3-GPTQ 3x8b (norm_rows=True)", "3x8b", True),
            ("M3-GPTQ 3x7b (norm_rows=True)", "3x7b", True),
        ]
        report = run_suite(
            args.model,
            Path(args.output_json),
            presets,
            args.calib_tokens,
            args.eval_tokens,
        )
        base_ppl = float(report["bf16_baseline"]["wikitext2_ppl"])

    out_p = Path(args.output_json)
    out_p.parent.mkdir(parents=True, exist_ok=True)
    baselines: list[dict[str, Any]] = list(report.get("external_baselines", []))
    done_methods = {b.get("method") for b in baselines}
    tasks = [
        ("BitsAndBytes NF4 (4-bit + double quant)", lambda: run_bnb_eval(args.model, "nf4", ev, tokenizer, device, base_ppl)),
        *( [("BitsAndBytes LLM.int8() (8-bit)", lambda: run_bnb_eval(args.model, "int8", ev, tokenizer, device, base_ppl))] if (args.include_int8 and not args.fast) else ()),
        *( [("GPTQ Scalar 4-bit (g=128)", lambda: run_scalar_gptq_eval(args.model, calib, ev, tokenizer, device, bits=4, base_ppl=base_ppl))] if not args.fast else ()),
        ("GPTQ Scalar 3-bit (g=128)", lambda: run_scalar_gptq_eval(args.model, calib, ev, tokenizer, device, bits=3, base_ppl=base_ppl)),
    ]
    for method_name, m_fn in tasks:
        if method_name in done_methods:
            print(f"SKIPPING already-completed baseline: {method_name}")
            continue
        res = m_fn()
        print("BASELINE:", json.dumps(res, ensure_ascii=False))
        baselines.append(res)
        report["external_baselines"] = baselines
        out_p.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"Saved full comparison report -> {out_p}")


if __name__ == "__main__":
    main()
