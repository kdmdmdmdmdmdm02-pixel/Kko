"""Paired 7B BF16 vs. ZAQERIS M3-GPTQ Benchmark Suite (8 GB Consumer GPU Compatible).

Evaluates:
  1. Uncompressed BF16 Baseline (CPU-offloaded block streaming -> fits 8 GB VRAM)
  2. ZAQERIS M3-GPTQ presets with `normalize_rows=True` (`3x8b` & `3x7b`), including:
     - Quantized linear BPW AND full-checkpoint total BPW / disk size
     - Mean matrix cosine similarity and relative L2 error
     - WikiText-2 (test split) Perplexity
     - Paired MMLU (100 stratified) & AI2 ARC-Challenge (100) accuracy via exact log-prob
     - Real save/reload via `save_m3_model` -> `load_m3_model(..., device="cuda")`
     - Loaded VRAM, Peak VRAM, and greedy generation throughput (`tok/s`)
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.ipc as pa_ipc
import torch
import torch.nn.functional as F
from transformers import AutoModelForCausalLM, AutoTokenizer

from zaqeris_m3_gptq import (
    M3Config,
    compress_causal_lm,
    load_m3_model,
    reset_cache,
    save_m3_model,
)
from zaqeris_m3_gptq.cli import evaluate_perplexity, load_token_splits
from zaqeris_m3_gptq.core import _compute_embed_hidden_and_kwargs, _discover_transformer_blocks, _run_block_streaming


HF_CACHE = Path(r"C:\Users\rahim\.cache\huggingface")


def _load_cached_arrow(glob_pat: str) -> list[dict[str, Any]]:
    matches = sorted(HF_CACHE.glob(glob_pat))
    if not matches:
        raise FileNotFoundError(f"Cached dataset file not found: {glob_pat}")
    p = matches[0]
    if p.suffix == ".parquet":
        import pandas as pd
        return pd.read_parquet(p).to_dict(orient="records")
    with open(p, "rb") as f:
        try:
            reader = pa_ipc.open_stream(f)
            tbl = reader.read_all()
        except pa.ArrowInvalid:
            f.seek(0)
            tbl = pa_ipc.open_file(f).read_all()
    return tbl.to_pylist()


@torch.no_grad()
def eval_streaming_all(
    model: torch.nn.Module,
    ev: torch.Tensor,
    tokenizer: Any,
    device: torch.device,
    limit: int = 100,
) -> tuple[float, dict[str, Any], dict[str, Any]]:
    """Single-pass layer-by-layer streaming eval for WikiText-2 + MMLU + ARC (200x faster than per-prompt offload)."""
    backbone = getattr(model, "model", None) or getattr(model, "transformer", None)
    embed = getattr(backbone, "embed_tokens", None) or getattr(backbone, "wte", None)
    norm = getattr(backbone, "norm", None) or getattr(backbone, "ln_f", None)
    lm_head = getattr(model, "lm_head", None)
    rotary_emb = getattr(backbone, "rotary_emb", None)

    mmlu_rows = _load_cached_arrow("hub/datasets--cais--mmlu/snapshots/*/all/test-*.parquet")
    step_m = max(1, len(mmlu_rows) // limit)
    mmlu_sample = mmlu_rows[::step_m][:limit]
    letters = ["A", "B", "C", "D"]
    mmlu_cids = [tokenizer.encode(f" {l}", add_special_tokens=False)[-1] for l in letters]
    arc_rows = _load_cached_arrow("datasets/allenai___ai2_arc/ARC-Challenge/*/*/ai2_arc-test.arrow")[:limit]

    embed.to(device)
    h_ev = torch.cat([embed(ev[i : i + 1].to(device)).detach().cpu() for i in range(ev.shape[0])], dim=0)
    mmlu_hs = [
        embed(
            tokenizer(
                f"Question: {r['question']}\n" + "\n".join(f"{letters[i]}. {r['choices'][i]}" for i in range(4)) + "\nAnswer:",
                return_tensors="pt",
                truncation=True,
                max_length=768,
            ).input_ids.to(device)
        ).detach().cpu()
        for r in mmlu_sample
    ]
    arc_items = []
    for r in arc_rows:
        lbs, txs = r["choices"]["label"], r["choices"]["text"]
        ids = tokenizer(
            f"Question: {r['question']}\n" + "\n".join(f"{lb}. {tx}" for lb, tx in zip(lbs, txs)) + "\nAnswer:",
            return_tensors="pt",
            truncation=True,
            max_length=768,
        ).input_ids.to(device)
        cids = [tokenizer.encode(f" {lb}", add_special_tokens=False)[-1] for lb in lbs]
        arc_items.append([embed(ids).detach().cpu(), cids, lbs, r["answerKey"]])
    embed.to("cpu")
    torch.cuda.empty_cache()

    pos_ev = torch.arange(ev.shape[1], dtype=torch.long, device=device).unsqueeze(0)
    rot_ev = None
    if rotary_emb is not None:
        rotary_emb.to(device)
        c_e, s_e = rotary_emb(h_ev[:1].to(device), pos_ev)
        rot_ev = (c_e.detach(), s_e.detach())

    for _, block in _discover_transformer_blocks(model):
        block.to(device)
        kw_ev: dict[str, Any] = {"position_ids": pos_ev, "use_cache": False}
        if rot_ev is not None:
            kw_ev["position_embeddings"] = rot_ev
        for i in range(h_ev.shape[0]):
            try:
                out = block(h_ev[i : i + 1].to(device), **kw_ev)
            except TypeError:
                out = block(h_ev[i : i + 1].to(device), position_ids=pos_ev, use_cache=False)
            h_ev[i : i + 1] = (out[0] if isinstance(out, tuple) else out).detach().cpu()

        for i in range(len(mmlu_hs)):
            hb = mmlu_hs[i].to(device)
            p_ids = torch.arange(hb.shape[1], dtype=torch.long, device=device).unsqueeze(0)
            kw = {"position_ids": p_ids, "use_cache": False}
            if rotary_emb is not None:
                kw["position_embeddings"] = rotary_emb(hb, p_ids)
            try:
                out = block(hb, **kw)
            except TypeError:
                out = block(hb, position_ids=p_ids, use_cache=False)
            mmlu_hs[i] = (out[0] if isinstance(out, tuple) else out).detach().cpu()

        for item in arc_items:
            hb = item[0].to(device)
            p_ids = torch.arange(hb.shape[1], dtype=torch.long, device=device).unsqueeze(0)
            kw = {"position_ids": p_ids, "use_cache": False}
            if rotary_emb is not None:
                kw["position_embeddings"] = rotary_emb(hb, p_ids)
            try:
                out = block(hb, **kw)
            except TypeError:
                out = block(hb, position_ids=p_ids, use_cache=False)
            item[0] = (out[0] if isinstance(out, tuple) else out).detach().cpu()

        block.to("cpu")
        torch.cuda.empty_cache()

    if rotary_emb is not None:
        rotary_emb.to("cpu")

    norm.to(device)
    lm_head.to(device)

    total_nll, total_tok = 0.0, 0
    for i in range(h_ev.shape[0]):
        hb = norm(h_ev[i : i + 1].to(device))
        lg = lm_head(hb)[:, :-1, :].float()
        tgt = ev[i : i + 1, 1:].to(device).reshape(-1)
        total_nll += F.cross_entropy(lg.reshape(-1, lg.shape[-1]), tgt, reduction="sum").item()
        total_tok += tgt.numel()
    ppl = math.exp(total_nll / total_tok)

    m_ok = 0
    for r, hb_c in zip(mmlu_sample, mmlu_hs):
        lg = lm_head(norm(hb_c[:, -1:, :].to(device)))[0, 0, :].float()
        pred = int(torch.tensor([lg[cid].item() for cid in mmlu_cids]).argmax().item())
        if pred == int(r["answer"]):
            m_ok += 1

    a_ok = 0
    for hb_c, cids, lbs, ans in arc_items:
        lg = lm_head(norm(hb_c[:, -1:, :].to(device)))[0, 0, :].float()
        pred = int(torch.tensor([lg[cid].item() for cid in cids]).argmax().item())
        if lbs[pred] == ans:
            a_ok += 1

    norm.to("cpu")
    lm_head.to("cpu")
    torch.cuda.empty_cache()
    return (
        ppl,
        {"evaluated": len(mmlu_sample), "correct": m_ok, "accuracy": round(m_ok / len(mmlu_sample), 4)},
        {"evaluated": len(arc_items), "correct": a_ok, "accuracy": round(a_ok / len(arc_items), 4)},
    )


@torch.no_grad()
def _forward_last_logits(model: torch.nn.Module, input_ids: torch.Tensor, device: torch.device) -> torch.Tensor:
    """Runs one prompt forward, streaming block-by-block if model is on CPU."""
    first_p = next(model.parameters(), None)
    if first_p is not None and first_p.device.type == "cuda":
        return model(input_ids.to(device), use_cache=False).logits[0, -1, :].float()

    # Streaming CPU -> CUDA block-by-block forward for BF16 7B baseline
    backbone = getattr(model, "model", None) or getattr(model, "transformer", None)
    embed = getattr(backbone, "embed_tokens", None) or getattr(backbone, "wte", None)
    norm = getattr(backbone, "norm", None) or getattr(backbone, "ln_f", None)
    lm_head = getattr(model, "lm_head", None)

    embed.to(device)
    h = embed(input_ids.to(device))
    embed.to("cpu")

    seq_len = input_ids.shape[1]
    pos_ids = torch.arange(seq_len, dtype=torch.long, device=device).unsqueeze(0)
    kw: dict[str, Any] = {"position_ids": pos_ids, "use_cache": False}
    rotary_emb = getattr(backbone, "rotary_emb", None)
    if rotary_emb is not None:
        rotary_emb.to(device)
        cos, sin = rotary_emb(h, pos_ids)
        kw["position_embeddings"] = (cos, sin)
        rotary_emb.to("cpu")

    for _, block in _discover_transformer_blocks(model):
        block.to(device)
        try:
            out = block(h, **kw)
        except TypeError:
            out = block(h, position_ids=pos_ids, use_cache=False)
        h = out[0] if isinstance(out, tuple) else out
        block.to("cpu")

    norm.to(device)
    h_last = norm(h[:, -1:, :])
    norm.to("cpu")
    lm_head.to(device)
    logits = lm_head(h_last)[0, 0, :].float()
    lm_head.to("cpu")
    return logits


@torch.no_grad()
def eval_mmlu_subset(
    model: torch.nn.Module,
    tokenizer: Any,
    device: torch.device,
    limit: int = 100,
) -> dict[str, Any]:
    rows = _load_cached_arrow("hub/datasets--cais--mmlu/snapshots/*/all/test-*.parquet")
    # Deterministic stratified sample
    step = max(1, len(rows) // limit)
    sample = rows[::step][:limit]
    letters = ["A", "B", "C", "D"]
    choice_ids = [tokenizer.encode(f" {l}", add_special_tokens=False)[-1] for l in letters]
    correct = 0
    for r in sample:
        choices = r["choices"]
        prompt = (
            f"Question: {r['question']}\n"
            + "\n".join(f"{letters[i]}. {choices[i]}" for i in range(4))
            + "\nAnswer:"
        )
        ids = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=768).input_ids
        logits = _forward_last_logits(model, ids, device)
        pred = int(torch.tensor([logits[cid].item() for cid in choice_ids]).argmax().item())
        if pred == int(r["answer"]):
            correct += 1
    return {"evaluated": len(sample), "correct": correct, "accuracy": round(correct / len(sample), 4)}


@torch.no_grad()
def eval_arc_subset(
    model: torch.nn.Module,
    tokenizer: Any,
    device: torch.device,
    limit: int = 100,
) -> dict[str, Any]:
    rows = _load_cached_arrow("datasets/allenai___ai2_arc/ARC-Challenge/*/*/ai2_arc-test.arrow")
    sample = rows[:limit]
    correct = 0
    for r in sample:
        labels = r["choices"]["label"]
        texts = r["choices"]["text"]
        prompt = (
            f"Question: {r['question']}\n"
            + "\n".join(f"{lb}. {tx}" for lb, tx in zip(labels, texts))
            + "\nAnswer:"
        )
        ids = tokenizer(prompt, return_tensors="pt", truncation=True, max_length=768).input_ids
        logits = _forward_last_logits(model, ids, device)
        cids = [tokenizer.encode(f" {lb}", add_special_tokens=False)[-1] for lb in labels]
        pred_idx = int(torch.tensor([logits[cid].item() for cid in cids]).argmax().item())
        if labels[pred_idx] == r["answerKey"]:
            correct += 1
    return {"evaluated": len(sample), "correct": correct, "accuracy": round(correct / len(sample), 4)}


@torch.no_grad()
def measure_decode_speed(model: torch.nn.Module, tokenizer: Any, device: torch.device, max_new_tokens: int = 48) -> float:
    prompt = "Write a Python function `is_prime(n: int) -> bool` with O(sqrt(n)) complexity."
    inputs = tokenizer(prompt, return_tensors="pt").to(device)
    # Warmup
    _ = model.generate(**inputs, max_new_tokens=4, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    if device.type == "cuda":
        torch.cuda.synchronize()
    t0 = time.perf_counter()
    out = model.generate(**inputs, max_new_tokens=max_new_tokens, do_sample=False, pad_token_id=tokenizer.eos_token_id)
    if device.type == "cuda":
        torch.cuda.synchronize()
    dt = max(time.perf_counter() - t0, 1e-6)
    n_gen = int(out.shape[1] - inputs["input_ids"].shape[1])
    return round(n_gen / dt, 2)


def run_suite(model_id: str, output_json: Path, presets: list[tuple[str, str, bool]], calib_tokens: int, eval_tokens: int) -> dict[str, Any]:
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    tokenizer = AutoTokenizer.from_pretrained(model_id)
    calib, ev = load_token_splits(
        tokenizer,
        calib_tokens=calib_tokens,
        eval_tokens=eval_tokens,
        seq_len=1024,
        wikitext=True,
    )

    print(f"\n=== [{model_id}] 1. BF16 Baseline (Streaming on 8 GB GPU) ===")
    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()
    try:
        model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()

    total_model_params = sum(p.numel() for p in model.parameters())
    bf16_total_bytes = sum(p.numel() * p.element_size() for p in model.parameters())

    t0 = time.time()
    first_p = next(model.parameters(), None)
    if first_p is not None and first_p.device.type == "cpu" and device.type == "cuda":
        base_ppl, base_mmlu, base_arc = eval_streaming_all(model, ev, tokenizer, device, limit=100)
        base_ppl_s = round(time.time() - t0, 1)
    else:
        base_ppl = evaluate_perplexity(model, ev, device=device, batch_size=1)
        base_ppl_s = round(time.time() - t0, 1)
        base_mmlu = eval_mmlu_subset(model, tokenizer, device, limit=100)
        base_arc = eval_arc_subset(model, tokenizer, device, limit=100)
    base_peak_vram = round(torch.cuda.max_memory_allocated() / (1024**3), 3) if device.type == "cuda" else 0.0

    report: dict[str, Any] = {
        "model_id": model_id,
        "total_params": total_model_params,
        "bf16_size_gib": round(bf16_total_bytes / (1024**3), 3),
        "calib_tokens": int(calib.numel()),
        "eval_tokens": int(ev.numel()),
        "dataset": "Salesforce/wikitext (wikitext-2-raw-v1)",
        "bf16_baseline": {
            "wikitext2_ppl": round(base_ppl, 4),
            "ppl_eval_seconds": base_ppl_s,
            "mmlu_100": base_mmlu,
            "arc_100": base_arc,
            "peak_vram_gib": base_peak_vram,
        },
        "runs": [],
    }
    print(f"  BF16 Baseline -> WikiText2 PPL={base_ppl:.4f} ({base_ppl_s}s) | MMLU={base_mmlu['accuracy']} | ARC={base_arc['accuracy']} | PeakVRAM={base_peak_vram} GiB")
    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
    del model
    gc.collect()
    if device.type == "cuda":
        torch.cuda.empty_cache()

    tmp_root = Path(tempfile.mkdtemp(prefix="m3_7b_"))
    try:
        for label, preset_key, norm_rows in presets:
            print(f"\n=== [{model_id}] Running {label} (preset={preset_key}, normalize_rows={norm_rows}) ===")
            reset_cache(budget_mib=1024.0, max_entry_mib=256.0)
            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats()

            try:
                model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()
            except TypeError:
                model = AutoModelForCausalLM.from_pretrained(model_id, torch_dtype=torch.bfloat16, low_cpu_mem_usage=True).eval()

            cfg = M3Config.from_preset(preset_key, normalize_rows=norm_rows)
            t_comp = time.time()
            stats = compress_causal_lm(
                model=model,
                calib_tokens=calib,
                config=cfg,
                replace_modules=True,
                use_cache=True,
                batch_size=1,
                device=device,
                offload="auto",
            )
            comp_s = round(time.time() - t_comp, 1)
            comp_peak_vram = round(torch.cuda.max_memory_allocated() / (1024**3), 3) if device.type == "cuda" else 0.0

            save_dir = tmp_root / f"{preset_key}_norm{int(norm_rows)}"
            save_m3_model(model, save_dir, config=cfg)
            del model
            gc.collect()
            if device.type == "cuda":
                torch.cuda.empty_cache()

            disk_bytes = sum(f.stat().st_size for f in save_dir.rglob("*.safetensors"))
            total_bpw = round((disk_bytes * 8.0) / total_model_params, 4)

            if device.type == "cuda":
                torch.cuda.reset_peak_memory_stats()
            reloaded = load_m3_model(save_dir, device=device, dtype=torch.bfloat16, use_cache=True)
            loaded_vram = round(torch.cuda.memory_allocated() / (1024**3), 3) if device.type == "cuda" else 0.0

            t_ev = time.time()
            q_ppl = evaluate_perplexity(reloaded, ev, device=device, batch_size=1)
            ev_s = round(time.time() - t_ev, 1)
            q_mmlu = eval_mmlu_subset(reloaded, tokenizer, device, limit=100)
            q_arc = eval_arc_subset(reloaded, tokenizer, device, limit=100)
            tok_s = measure_decode_speed(reloaded, tokenizer, device, max_new_tokens=48)
            eval_peak_vram = round(torch.cuda.max_memory_allocated() / (1024**3), 3) if device.type == "cuda" else 0.0

            entry = {
                "label": label,
                "preset": preset_key,
                "normalize_rows": norm_rows,
                "linear_bpw": round(stats["effective_bpw"], 4),
                "total_checkpoint_bpw": total_bpw,
                "disk_gib": round(disk_bytes / (1024**3), 3),
                "mean_cosine": round(stats["mean_cosine"], 5),
                "mean_rel_l2": round(stats["mean_rel_l2"], 5),
                "compress_seconds": comp_s,
                "compress_peak_vram_gib": comp_peak_vram,
                "loaded_vram_gib": loaded_vram,
                "eval_peak_vram_gib": eval_peak_vram,
                "wikitext2_ppl": round(q_ppl, 4),
                "ppl_ratio_vs_bf16": round(q_ppl / base_ppl, 4),
                "ppl_eval_seconds": ev_s,
                "mmlu_100": q_mmlu,
                "arc_100": q_arc,
                "decode_tokens_per_sec": tok_s,
            }
            report["runs"].append(entry)
            output_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
            print(
                f"  {label} -> linear_bpw={entry['linear_bpw']} | total_bpw={total_bpw} ({entry['disk_gib']} GiB) | "
                f"cos={entry['mean_cosine']} | PPL={entry['wikitext2_ppl']} ({entry['ppl_ratio_vs_bf16']}x) | "
                f"MMLU={q_mmlu['accuracy']} | ARC={q_arc['accuracy']} | {tok_s} tok/s | VRAM={loaded_vram}/{eval_peak_vram} GiB"
            )

            del reloaded
            shutil.rmtree(save_dir, ignore_errors=True)
            gc.collect()
            if device.type == "cuda":
                torch.cuda.empty_cache()
    finally:
        shutil.rmtree(tmp_root, ignore_errors=True)

    output_json.parent.mkdir(parents=True, exist_ok=True)
    output_json.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\nSaved 7B report -> {output_json}")
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--output-json", required=True)
    parser.add_argument("--calib-tokens", type=int, default=32768)
    parser.add_argument("--eval-tokens", type=int, default=32768)
    parser.add_argument("--presets", nargs="+", default=["3x8b", "3x7b"], choices=["3x8b", "3x7b", "3x8b_tight"])
    args = parser.parse_args()

    presets = [(f"M3-GPTQ {p} (norm_rows=True)", p, True) for p in args.presets]
    run_suite(args.model, Path(args.output_json), presets, args.calib_tokens, args.eval_tokens)


if __name__ == "__main__":
    main()
