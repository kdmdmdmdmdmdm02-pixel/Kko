# NVRTC LUT + CUDA Graph Reference Kernel (`ZQN-12B`)

يحتوي هذا المجلد على الملف المرجعي [`modeling_zaqeris_zaqion_12b.py`](./modeling_zaqeris_zaqion_12b.py) الذي يضم تنفيذ كيرنل **NVRTC LUT + Static CUDA Graph** المخصص لنموذج `ZAQERIS/ZQN-12B`.

## فرق السرعة عن الحزمة العامة (`M3Linear`)
- **الحزمة العامة (`zaqeris_m3_gptq/runtime.py` — `M3Linear`):** تستخدم حالياً مسار فك ضغط مرجعي بلغة PyTorch يُعيد بناء مصفوفة الأوزان قبل الضرب، ولذلك تسجل **`0.19–1.53 tokens/sec`** في الاختبارات.
- **التنفيذ المخصص لـ `ZQN-12B` (`modeling_zaqeris_zaqion_12b.py`):** يستخدم كيرنل `NVRTC` للضرب المباشر عبر جداول البحث (LUT) مع `Static CUDA Graph` لتسجيل **`22.94 tokens/sec`** على نموذج `15.55B` داخل `8 GB VRAM`.
- **لا يجوز الخلط بين الرقمين:** سرعة `22.94 tok/s` خاصة بالمسار المخصص لـ `ZQN-12B` وليست سرعة الحزمة العامة `zaqeris-m3-gptq v0.1.0` الحالية؛ ودمج هذا الكيرنل داخل `M3Linear` هو الهدف الهندسي الرئيسي للإصدار `v0.2`.
