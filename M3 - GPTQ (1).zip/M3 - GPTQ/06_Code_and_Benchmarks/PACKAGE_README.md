# ZAQERIS M3-GPTQ

**Hessian-Aware Multi-Stage Residual Vector Quantization with Block-Hadamard Decorrelation and OBQ Salient Outliers.**

[![License](https://img.shields.io/badge/License-Apache_2.0-blue.svg)](LICENSE)
[![Python](https://img.shields.io/badge/Python-3.10%2B-green.svg)]()
[![PyTorch](https://img.shields.io/badge/PyTorch-2.1%2B-orange.svg)]()

`zaqeris-m3-gptq` is an open-source post-training weight quantization engine and runtime for Large Language Models (LLMs). By unifying four complementary components—(1) memory-lean Block-Hadamard ($g=128$) orthogonal decorrelation, (2) Optimal Brain Quantization (OBQ) Hessian-salience outlier protection ($w^2 / [H^{-1}]_{jj}$), (3) multi-stage 8D Euclidean Residual Vector Quantization (RVQ) with tight sub-byte index packing, and (4) Block-8 Cholesky GPTQ error propagation—M3-GPTQ achieves stable, high-fidelity LLM compression from **3.25 bpw** down to **2.13 bpw** within **5.78 GiB peak VRAM** on an 8 GB consumer GPU.

---

## Installation

```bash
git clone <repo-url>
cd zaqeris-m3-gptq
pip install -e .
```

For running tests:

```bash
pip install -e ".[dev]"
pytest
```

---

## Hardware Requirements

- **Compression (1.5B–3B models):** Single 8 GB VRAM GPU (verified peak VRAM: **5.782 GiB** for Qwen2.5-Coder-1.5B across all 28 decoder layers via layer-by-layer Hessian collection) or CPU.
- **Inference:** PyTorch `float16`, `bfloat16`, or `float32` on CUDA or CPU via `M3Linear` with an optional two-pool `ResidentWeightCache` (`ZAQERIS_M3_CACHE_MIB`, default 384 MiB; set `0` to disable).

---

## Quickstart

### Python API

```python
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer
from zaqeris_m3_gptq import M3Config, compress_causal_lm, save_m3_model, load_m3_model

model_id = "Qwen/Qwen2.5-Coder-1.5B"
tokenizer = AutoTokenizer.from_pretrained(model_id)
model = AutoModelForCausalLM.from_pretrained(model_id, dtype=torch.bfloat16).to("cuda").eval()

# Prepare calibration token blocks (e.g., 32 sequences of 1024 tokens)
calib_ids = tokenizer("def hello(): return 'world'\n" * 2048, return_tensors="pt").input_ids[0]
calib_batches = calib_ids[: 32 * 1024].view(32, 1024)

# Compress using the 3x7b (~2.75 bpw) sweet-spot preset
config = M3Config.from_preset("3x7b")
stats = compress_causal_lm(model, calib_batches, config=config, replace_modules=True)
print(f"Effective BPW: {stats['effective_bpw']:.4f} | Cosine: {stats['mean_cosine']:.5f}")

# Save and reload compressed model
save_m3_model(model, "./qwen25_coder_1.5b_m3_3x7b", config=config)
reloaded = load_m3_model("./qwen25_coder_1.5b_m3_3x7b", device="cuda", dtype=torch.bfloat16)
```

### Single-Layer Quantization & Reconstruction

```python
import torch
from zaqeris_m3_gptq import m3_gptq_quantize, dequantize_m3_weight, save_m3_layer, load_m3_layer

w = torch.randn(512, 512, device="cuda")
x = torch.randn(256, 512, device="cuda")
h = (x.t() @ x) / x.shape[0]

res = m3_gptq_quantize(w, h, stages=3, cb_size=128, outlier_ratio=0.0025)
w_hat = dequantize_m3_weight(res, device="cuda")
print(f"bpw={res.effective_bpw:.4f}, cos={res.cosine:.5f}, rel_l2={res.rel_l2:.5f}")

save_m3_layer(res, "layer.safetensors")
loaded = load_m3_layer("layer.safetensors", reconstruct=True)
```

### Command-Line Interface (`zaqeris-m3`)

```bash
# Compress a HuggingFace or local model
zaqeris-m3 compress --model Qwen/Qwen2.5-Coder-1.5B --output ./out_m3_3x7b --preset 3x7b --corpus-dir ./my_corpus

# Evaluate perplexity of a compressed checkpoint
zaqeris-m3 eval --checkpoint ./out_m3_3x7b --corpus-dir ./my_corpus --eval-tokens 65536

# Run multi-preset ablation benchmark
zaqeris-m3 benchmark --model Qwen/Qwen2.5-Coder-1.5B --corpus-dir ./my_corpus --output-json bench.json
```

---

## Verified Empirical Pareto Frontier

Measured on **Qwen2.5-Coder-1.5B** (`calib_tokens = 32,768`, `eval_tokens = 98,304` held-out code + markdown corpus, BF16 baseline **PPL = 5.3418**, peak M3-GPTQ VRAM **5.782 GiB**):

| Method | Effective BPW | Mean Rel L2 | Mean Cosine | Eval PPL | Ratio vs BF16 | Runtime (s) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **BF16 Baseline** | 16.0000 | 0.00000 | 1.00000 | **5.3418** | 1.0000x | — |
| GPTQ + Hadamard (4-bit) | 4.1250 | 0.14097 | 0.99018 | 5.4383 | 1.0181x | 383.3 |
| **M3-GPTQ (`3x8b`, 0.5% OBQ)** | **3.2534** | 0.25096 | **0.96789** | **5.7666** | **1.0795x** | 649.1 |
| **M3-GPTQ Tight (`3x8b`, 0.25% OBQ)** | **3.1339** | 0.25779 | **0.96609** | **5.8038** | **1.0865x** | 449.2 |
| GPTQ + Hadamard (3-bit) | 3.1250 | 0.30369 | 0.95681 | 5.9150 | 1.1073x | 666.6 |
| **M3-GPTQ `3x7b` (0.25% OBQ)** | **2.7515** | 0.32173 | **0.94682** | **6.2202** | **1.1644x** | 458.7 |
| M3+ (Hadamard + 3x8b, no Hessian) | 3.2536 | 0.19286 | 0.98128 | 6.5363 | 1.2236x | 94.2 |
| **M3-GPTQ `4x5b` (0.25% OBQ)** | **2.6217** | 0.36894 | 0.92950 | **6.7483** | **1.2633x** | 539.9 |
| Pure M3 (3-stage, 8b, int32 out) | 3.8141 | 0.19684 | 0.98059 | 6.8641 | 1.2850x | 55.0 |
| **M3-GPTQ `3x6b` (0.25% OBQ)** | **2.3729** | 0.39942 | 0.91717 | **7.3194** | **1.3702x** | 518.2 |
| **M3-GPTQ `2x8b` (0.25% OBQ)** | **2.1291** | 0.42802 | 0.90502 | **8.2920** | **1.5523x** | 364.6 |
| Pure M3 (2-stage, 8b, int32 out) | 2.8092 | 0.32494 | 0.94593 | 21.3112 | 3.9895x | 75.8 |
| M3+ Compact (Hadamard + 3x4b, no Hessian) | 1.7398 | 0.46914 | 0.88314 | 92182.0901 | 17256.6702x | 44.0 |

### End-to-End 28-Layer Pipeline Verification

Evaluated on `65,536` held-out tokens across a full 3-stage pipeline (`peak_vram = 6.424 GiB`, `total_seconds = 470.5s`):

1. **Stage 1 (28-Layer Contextual Merge):** `PPL = 4.9813` (`49.1s`)
2. **Stage 2 (RoPE-Safe Orthogonal Gauge Rotation):** `PPL = 4.9878` (`drift = 0.0065`, `1.2s`)
3. **Stage 3 (M3-GPTQ `3x7b` at `2.7517` bpw):** `mean_cosine = 0.94919`, `mean_rel_l2 = 0.31475`, `PPL = 5.8726` (`1.1789x` vs merged BF16, `345.3s`)

See the full technical paper in [paper/ZAQERIS_M3_GPTQ_PAPER.md](paper/ZAQERIS_M3_GPTQ_PAPER.md).

---

## Reproducing Benchmarks

```bash
python benchmarks/reproduce_m3_benchmarks.py \
  --model Qwen/Qwen2.5-Coder-1.5B \
  --corpus-dir /path/to/corpus \
  --calib-tokens 32768 \
  --eval-tokens 98304 \
  --output-json results_m3_reproduced.json
```

---

## License

Licensed under the [Apache License 2.0](LICENSE).
