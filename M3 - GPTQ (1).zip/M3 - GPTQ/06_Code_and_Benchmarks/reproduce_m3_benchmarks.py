"""Reproducible Empirical Benchmark Suite for ZAQERIS M3-GPTQ.

Evaluates actual Perplexity (no synthetic or hardcoded numbers), mean cosine
similarity, relative L2 weight error, effective bits-per-weight, memory
footprint, and elapsed wall-clock time on any HuggingFace or local CausalLM
checkpoint.

Compares:
  1. BF16 Baseline
  2. Hadamard + RVQ (3x8b, non-Hessian ablation)
  3. M3-GPTQ presets: 3x8b Tight, 3x7b, 4x5b, 3x6b, 2x8b

Example:
  python benchmarks/reproduce_m3_benchmarks.py \
    --model Qwen/Qwen2.5-Coder-1.5B \
    --corpus-dir /path/to/heldout_corpus \
    --output-json benchmark_results.json
"""

from __future__ import annotations

import argparse
import gc
import json
import math
import time
from pathlib import Path
from typing import Any

import torch
from transformers import AutoModelForCausalLM, AutoTokenizer

from zaqeris_m3_gptq.cli import evaluate_perplexity, load_token_splits
from zaqeris_m3_gptq.core import (
    M3Config,
    compress_causal_lm,
    make_hadamard_block,
    quantize_8col_rvq,
    train_rvq_codebooks,
)


PRESET_SCHEDULE: list[tuple[str, str]] = [
    ("M3-GPTQ 3x8b Tight", "3x8b_tight"),
    ("M3-GPTQ 3x7b", "3x7b"),
    ("M3-GPTQ 4x5b", "4x5b"),
    ("M3-GPTQ 3x6b", "3x6b"),
    ("M3-GPTQ 2x8b", "2x8b"),
]


@torch.no_grad()
def run_hadamard_rvq_ablation(
    model: torch.nn.Module,
    orig_cpu: dict[str, torch.Tensor],
    r_g: torch.Tensor,
    device: str,
    stages: int = 3,
    cb_size: int = 256,
    outlier_ratio: float = 0.005,
) -> dict[str, float | int]:
    """Runs non-Hessian Hadamard + 8D RVQ quantization across all linear layers."""
    total_bytes = 0
    total_params = 0
    rels: list[float] = []
    coss: list[float] = []
    linear_mods = {
        n: m
        for n, m in model.named_modules()
        if isinstance(m, torch.nn.Linear) and "lm_head" not in n
    }

    for name, mod in linear_mods.items():
        w0 = orig_cpu[name].to(device=device, dtype=torch.float32)
        m, n = w0.shape
        g = r_g.shape[0]
        w_rot = (w0.view(m, n // g, g) @ r_g).reshape(m, n).clone()
        total = m * n

        n_out = max(1, int(total * outlier_ratio))
        if total > 8_388_608:
            step = max(1, total // 2_097_152)
            thresh = torch.topk(w_rot.abs().reshape(-1)[::step], max(1, n_out // step)).values[-1]
        else:
            thresh = torch.topk(w_rot.abs().reshape(-1), n_out).values[-1]
        out_mask = w_rot.abs() >= thresh
        if int(out_mask.sum().item()) > n_out:
            nz = torch.nonzero(out_mask, as_tuple=False)
            top_idx = torch.topk(w_rot[nz[:, 0], nz[:, 1]].abs(), n_out).indices
            out_mask.zero_()
            sel = nz[top_idx]
            out_mask[sel[:, 0], sel[:, 1]] = True
        actual_out = int(out_mask.sum().item())

        w_src = w_rot.clone()
        w_src[out_mask] = 0.0
        cbs = train_rvq_codebooks(w_src.reshape(-1, 8), name=name, stages=stages, cb_size=cb_size, iters=8)
        q_vecs = quantize_8col_rvq(w_src.reshape(-1, 8), cbs)
        q_rot = q_vecs.reshape(m, n)
        q_rot[out_mask] = w_rot[out_mask].half().float()
        w_hat = (q_rot.view(m, n // g, g) @ r_g.t()).reshape(m, n)

        mod.weight.copy_(w_hat.to(mod.weight.dtype))
        idx_bits = max(1, int(math.ceil(math.log2(cb_size))))
        num_vecs = total // 8
        total_bytes += stages * (cb_size * 8 * 2 + (num_vecs * idx_bits + 7) // 8) + actual_out * 6 + 12
        total_params += total
        rels.append(((w_hat - w0).norm() / w0.norm().clamp_min(1e-12)).item())
        coss.append(torch.nn.functional.cosine_similarity(w_hat.reshape(1, -1), w0.reshape(1, -1)).item())

    return {
        "effective_bpw": total_bytes * 8.0 / total_params,
        "mean_rel_l2": sum(rels) / len(rels),
        "mean_cosine": sum(coss) / len(coss),
        "total_storage_bytes": total_bytes,
        "total_params": total_params,
    }


def main() -> None:
    parser = argparse.ArgumentParser(description="Reproduce ZAQERIS M3-GPTQ empirical benchmarks.")
    parser.add_argument("--model", required=True, help="HuggingFace model ID or local checkpoint path.")
    parser.add_argument("--corpus-dir", default=None, help="Directory of .py/.md/.txt files for calib/eval.")
    parser.add_argument("--text-file", default=None, help="Single text file for calib/eval.")
    parser.add_argument("--calib-tokens", type=int, default=32768)
    parser.add_argument("--eval-tokens", type=int, default=98304)
    parser.add_argument("--seq-len", type=int, default=1024)
    parser.add_argument("--device", default="cuda" if torch.cuda.is_available() else "cpu")
    parser.add_argument("--dtype", default="bfloat16", choices=["bfloat16", "float16", "float32"])
    parser.add_argument("--output-json", default="results_m3_reproduced.json")
    args = parser.parse_args()

    dtype_map = {
        "bfloat16": torch.bfloat16,
        "float16": torch.float16,
        "float32": torch.float32,
    }
    torch_dtype = dtype_map[args.dtype]

    if args.device == "cuda":
        torch.cuda.reset_peak_memory_stats()

    tokenizer = AutoTokenizer.from_pretrained(args.model)
    calib, ev = load_token_splits(
        tokenizer,
        calib_tokens=args.calib_tokens,
        eval_tokens=args.eval_tokens,
        seq_len=args.seq_len,
        corpus_dir=args.corpus_dir,
        text_file=args.text_file,
    )

    try:
        model = AutoModelForCausalLM.from_pretrained(args.model, dtype=torch_dtype)
    except TypeError:
        model = AutoModelForCausalLM.from_pretrained(args.model, torch_dtype=torch_dtype)
    model = model.to(args.device).eval()
    if hasattr(model, "config") and hasattr(model.config, "use_cache"):
        model.config.use_cache = False
    model.requires_grad_(False)

    t0 = time.time()
    baseline_ppl = evaluate_perplexity(model, ev, device=args.device)
    baseline_time = time.time() - t0

    linear_mods = {
        n: m
        for n, m in model.named_modules()
        if isinstance(m, torch.nn.Linear) and "lm_head" not in n
    }
    orig_cpu = {n: m.weight.detach().clone().cpu() for n, m in linear_mods.items()}
    total_quant_params = sum(w.numel() for w in orig_cpu.values())
    bf16_bytes = total_quant_params * 2

    print(f"Model: {args.model} | Quantized linear params: {total_quant_params:,} ({bf16_bytes / (1024**2):.1f} MiB in BF16)")
    print(f"Calib tokens: {calib.numel():,} | Eval tokens: {ev.numel():,}")
    print(f"{'Method':38s} {'BPW':>7s} {'MiB':>8s} {'Cosine':>8s} {'Rel L2':>8s} {'PPL':>10s} {'Ratio':>8s} {'Time(s)':>8s}")
    print("-" * 102)
    print(
        f"{'BF16 Baseline':38s} {'16.000':>7s} {bf16_bytes / (1024**2):8.1f} {'1.00000':>8s} {'0.00000':>8s} "
        f"{baseline_ppl:10.4f} {'1.0000':>8s} {baseline_time:8.1f}"
    )

    runs: list[dict[str, Any]] = []
    r_g = make_hadamard_block(block_dim=128, seed=1234, device=args.device)

    def _restore() -> None:
        for name, mod in linear_mods.items():
            mod.weight.copy_(orig_cpu[name].to(device=args.device, dtype=mod.weight.dtype))
        gc.collect()
        if args.device == "cuda":
            torch.cuda.empty_cache()

    # 1. Hadamard + RVQ (non-Hessian ablation)
    t_run = time.time()
    rvq_stats = run_hadamard_rvq_ablation(model, orig_cpu, r_g, device=args.device)
    rvq_ppl = evaluate_perplexity(model, ev, device=args.device)
    rvq_sec = time.time() - t_run
    rvq_mib = rvq_stats["total_storage_bytes"] / (1024**2)
    rvq_entry = {
        "method": "Hadamard + RVQ (3x8b, no Hessian)",
        "effective_bpw": round(float(rvq_stats["effective_bpw"]), 4),
        "storage_mib": round(rvq_mib, 2),
        "mean_rel_l2": round(float(rvq_stats["mean_rel_l2"]), 5),
        "mean_cosine": round(float(rvq_stats["mean_cosine"]), 5),
        "ppl": round(rvq_ppl, 4),
        "ratio": round(rvq_ppl / baseline_ppl, 4),
        "seconds": round(rvq_sec, 1),
    }
    runs.append(rvq_entry)
    print(
        f"{rvq_entry['method']:38s} {rvq_entry['effective_bpw']:7.4f} {rvq_entry['storage_mib']:8.1f} "
        f"{rvq_entry['mean_cosine']:8.5f} {rvq_entry['mean_rel_l2']:8.5f} {rvq_entry['ppl']:10.4f} "
        f"{rvq_entry['ratio']:8.4f} {rvq_entry['seconds']:8.1f}"
    )
    _restore()

    # 2. M3-GPTQ presets
    for label, preset_key in PRESET_SCHEDULE:
        cfg = M3Config.from_preset(preset_key)
        t_run = time.time()
        stats = compress_causal_lm(
            model=model,
            calib_tokens=calib,
            config=cfg,
            replace_modules=False,
            device=args.device,
        )
        p = evaluate_perplexity(model, ev, device=args.device)
        sec = time.time() - t_run
        mib = stats["total_storage_bytes"] / (1024**2)
        entry = {
            "method": label,
            "preset": preset_key,
            "effective_bpw": round(stats["effective_bpw"], 4),
            "storage_mib": round(mib, 2),
            "mean_rel_l2": round(stats["mean_rel_l2"], 5),
            "mean_cosine": round(stats["mean_cosine"], 5),
            "ppl": round(p, 4),
            "ratio": round(p / baseline_ppl, 4),
            "seconds": round(sec, 1),
        }
        runs.append(entry)
        print(
            f"{label:38s} {entry['effective_bpw']:7.4f} {entry['storage_mib']:8.1f} "
            f"{entry['mean_cosine']:8.5f} {entry['mean_rel_l2']:8.5f} {entry['ppl']:10.4f} "
            f"{entry['ratio']:8.4f} {entry['seconds']:8.1f}"
        )
        _restore()

    report: dict[str, Any] = {
        "model": args.model,
        "baseline_ppl": round(baseline_ppl, 6),
        "bf16_linear_mib": round(bf16_bytes / (1024**2), 2),
        "calib_tokens": int(calib.numel()),
        "eval_tokens": int(ev.numel()),
        "runs": runs,
    }
    if args.device == "cuda":
        report["peak_vram_gib"] = round(torch.cuda.max_memory_allocated() / (1024**3), 3)

    out_path = Path(args.output_json)
    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text(json.dumps(report, indent=2), encoding="utf-8")
    print(f"\nSaved benchmark report to {out_path}")


if __name__ == "__main__":
    main()
