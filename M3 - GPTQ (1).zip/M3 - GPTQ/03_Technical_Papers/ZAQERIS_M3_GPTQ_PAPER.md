# ZAQERIS M3-GPTQ: Hessian-Aware Multi-Stage Residual Vector Quantization for Extreme Bitrate LLM Compression

**Authors:** ZAQERIS AI Engineering Core  
**Release:** Open-Source Reference Implementation (`zaqeris-m3-gptq v0.1.0`)

---

## Abstract

Post-training quantization (PTQ) of Large Language Models below 3.5 bits per weight (bpw) exposes a fundamental failure mode in weight-space-only vector quantizers: minimizing Frobenius reconstruction error $\|W - \widehat{W}\|_F^2$ without second-order curvature awareness can yield high weight cosine similarity while suffering severe perplexity degradation. Conversely, scalar uniform quantization with Hessian feedback (e.g., 3-bit GPTQ) suffers from coarse scalar grid spacing as bitwidths drop below 3 bits.

We present **ZAQERIS M3-GPTQ**, a unified Hessian-aware vector quantization engine combining four mechanisms: (1) memory-lean Block-Hadamard ($g=128$) orthogonal decorrelation, (2) Optimal Brain Quantization (OBQ) Hessian-salience outlier selection ($w^2 / [H^{-1}]_{jj}$), (3) multi-stage 8-dimensional Euclidean Residual Vector Quantization (RVQ) with compact bit-packed indices across arbitrary codebook sizes ($2^5$ to $2^8$), and (4) Block-8 Cholesky GPTQ error propagation. On Qwen2.5-Coder-1.5B evaluated over 98,304 held-out tokens (BF16 baseline $\text{PPL} = 5.3418$), M3-GPTQ resolves the non-Hessian RVQ collapse—reducing 3.25 bpw perplexity from **6.5363** (non-Hessian M3+) to **5.7666** ($1.0795\times$ BF16)—and outperforms 3-bit GPTQ + Hadamard (**5.8038** at 3.1339 bpw vs **5.9150** at 3.1250 bpw), while maintaining coherent perplexity all the way down to **2.1291 bpw** (**8.2920 PPL**) inside a **5.782 GiB** peak VRAM envelope.

---

## الملخص التنفيذي (Arabic Executive Summary)

تُعاني تقنيات تكميم النماذج اللغوية الكبيرة بعد التدريب (Post-Training Quantization) عند المعدلات المنخفضة (أقل من 3.5 بت لكل معامل) من فجوة واضحة بين دقة إعادة بناء الأوزان هندسياً وجودة التوليد اللغوي الفعلية (Perplexity). فعند استخدام التكميم المتجهي المتبقي (RVQ) دون مراعاة مصفوفة هيسيان (Hessian) لتنشيطات الطبقة، قد يحقق النموذج تشابه جيب تمام (Cosine Similarity) مرتفعاً للأوزان، لكنه يتعرض لارتفاع حاد في الحيرة اللغوية (Perplexity) أو انهيار كامل عند المعدلات فائقة الانخفاض (مثل $92182.0901$ عند $1.7398$ بت/معامل في نظام `M3+ Compact`).

نقدم في هذه الورقة محرك **ZAQERIS M3-GPTQ** مفتوح المصدر، الذي يدمج أربع ركائز رياضية متكاملة:
1. **إزالة الارتباط المتعامد (Block-Hadamard $g=128$)** لتوزيع القيم الشاذة بذاكرة منخفضة عبر إعادة تشكيل المصفوفات دون بناء مصفوفات قطرية ضخمة.
2. **انتقاء القيم الشاذة بأهمية هيسيان (OBQ Salience)** وفق المعيار $w^2 / [H^{-1}]_{jj}$ لحماية المعاملات الأكثر تأثيراً في مخرجات الطبقة بدقة `float16` وفهارس مضغوطة (`uint16`).
3. **التكميم المتجهي المتبقي متعدد المراحل (Multi-Stage 8D RVQ)** بمرونة كاملة في معدلات البت (`3x8b`, `3x7b`, `4x5b`, `3x6b`, `2x8b`).
4. **تغذية راجعة للأخطاء بكتل ثمانية (Block-8 Cholesky GPTQ Error Propagation)** لتعويض خطأ التكميم المتجهي عبر الأعمدة المتبقية.

تُظهر القياسات التجريبية على نموذج `Qwen2.5-Coder-1.5B` (عبر $98,304$ رمز تقييم، وخط أساس BF16 عند $\text{PPL} = 5.3418$) أن `M3-GPTQ` يحسن الحيرة اللغوية عند $3.2534$ بت/معامل من $6.5363$ إلى **$5.7666$** ($1.0795\times$)، ويتفوق على `GPTQ + Hadamard (3-bit)` عند $3.1339$ بت/معامل (**$5.8038$** مقابل $5.9150$)، كما يفتح نقطة توازن مثالية عند $2.7515$ بت/معامل (`3x7b`) بحيرة لغوية **$6.2202$**، مع استهلاك ذروة ذاكرة فيديو لا يتجاوز **$5.782\text{ GiB}$**.

---

## 1. Introduction: Why Non-Hessian RVQ and Naive Sub-3-Bit Quantization Break

Empirical evaluation reveals a counterintuitive decoupling between static weight reconstruction fidelity and end-to-end language modeling loss. On Qwen2.5-Coder-1.5B (`baseline_ppl = 5.3418`, evaluated on `98,304` tokens with `32,768` calibration tokens):

- **Non-Hessian Hadamard RVQ (`M3+`, 3.2536 bpw)** achieves higher mean weight cosine similarity (**0.98128**) and lower relative $L_2$ weight error (**0.19286**) than **3-bit GPTQ + Hadamard** (**0.95681** cosine, **0.30369** relative $L_2$ at 3.1250 bpw).
- Yet **3-bit GPTQ + Hadamard** achieves substantially better perplexity (**5.9150** vs **6.5363** for `M3+`).

At lower bitrates, the absence of second-order curvature weighting and error compensation becomes catastrophic:
- **Pure M3 (2-stage, 8b, 2.8092 bpw)** degrades to **PPL = 21.3112** ($3.9895\times$ baseline).
- **M3+ Compact (Hadamard + 3-stage 4b, 1.7398 bpw)** collapses completely to **PPL = 92182.0901** ($17256.6702\times$ baseline), even though its mean weight cosine similarity remains `0.88314`.

This happens for two structural reasons:
1. **Uniform weight-space loss ignores input activation covariance.** Given layer input activations $X \in \mathbb{R}^{N_{\text{tok}} \times n}$, the output perturbation is $\|X \Delta W^T\|_F^2 = \operatorname{tr}(\Delta W H \Delta W^T)$, where $H = \frac{1}{N_{\text{tok}}} X^T X$. Protecting weight outliers by raw $|w_{ij}|$ protects weights that may sit on low-variance input channels while leaving small weights on high-curvature directions uncompensated.
2. **Uncorrelated block errors accumulate coherently across columns.** Quantizing 8-column blocks independently causes quantization residuals $\Delta W_{:, J}$ to project directly onto downstream outputs without cancellation across the remaining columns $R = \{g_1, \dots, n-1\}$.

**ZAQERIS M3-GPTQ** resolves both failure modes by embedding 8D Residual Vector Quantization directly inside a Block-8 Cholesky GPTQ loop with OBQ Hessian salience.

---

## 2. Mathematical Formulation

Let $W_0 \in \mathbb{R}^{m \times n}$ denote a linear layer weight matrix and $H = \frac{1}{N_{\text{tok}}} X^T X \in \mathbb{R}^{n \times n}$ denote its empirical input Hessian. Let $g = 128$ be the Hadamard group size ($g \mid n$) and $B = 8$ be the RVQ vector dimension ($B \mid g$).

### 2.1 Memory-Lean Block-Hadamard Decorrelation

We construct a single $g \times g$ randomized orthonormal Walsh-Hadamard block:

$$R_g = \operatorname{diag}(s) \cdot \frac{1}{\sqrt{g}} H_g, \qquad s \in \{-1, +1\}^g, \qquad R_g^T R_g = I_g$$

Instead of materializing the full $n \times n$ block-diagonal matrix $\operatorname{blkdiag}(R_g, \dots, R_g)$ (which requires $O(n^2)$ memory), we apply the orthogonal gauge transform via tensor reshaping:

$$W_{\text{rot}} = \operatorname{reshape}_{m \times n}\!\left(\operatorname{reshape}_{m \times (n/g) \times g}(W_0) \cdot R_g\right)$$

$$H_{\text{rot}} = \operatorname{reshape}_{n \times n}\!\left(\operatorname{einsum}_{ic,aibj,jd \to acbd}\!\left(R_g, \operatorname{reshape}_{(n/g) \times g \times (n/g) \times g}(H), R_g\right)\right)$$

Because $R_g$ is orthonormal, $X W_0^T = (X R_{\text{blk}}) W_{\text{rot}}^T$ preserves layer outputs identically while dispersing heavy-tailed channel outliers across each $128$-dimensional group.

### 2.2 Damped Cholesky Inverse and OBQ Salience

Dead input channels ($\operatorname{diag}(H_{\text{rot}})_j = 0$) are masked ($\operatorname{diag}(H_{\text{rot}})_{jj} \leftarrow 1$, $(W_{\text{rot}})_{:, j} \leftarrow 0$) and Tikhonov damping is applied:

$$\widetilde{H} = H_{\text{rot}} + \lambda \, \overline{\operatorname{diag}(H_{\text{rot}})} \, I_n, \qquad \lambda = 0.01$$

We compute the upper-triangular Cholesky factor $U$ of $\widetilde{H}^{-1}$ such that $U^T U = \widetilde{H}^{-1}$ (in PyTorch: `Hinv = cholesky(cholesky_inverse(cholesky(H)), upper=True)`). The exact diagonal of $\widetilde{H}^{-1}$ is obtained directly from the column squared norms of $U$:

$$[\widetilde{H}^{-1}]_{jj} = \|U_{:, j}\|_2^2$$

Under Optimal Brain Quantization (OBQ), pruning or quantizing a single weight $w_{ij}$ induces minimum output squared error proportional to:

$$S_{ij} = \frac{(W_{\text{rot}})_{ij}^2}{[\widetilde{H}^{-1}]_{jj}}$$

The top $r \in \{0.25\%, 0.5\%\}$ entries ranked by $S_{ij}$ form the sparse outlier mask $\Omega \subset \{1,\dots,m\}\times\{1,\dots,n\}$. Outlier values are stored in `float16` alongside `uint16` $(i, j)$ coordinates (4 bytes per coordinate pair for $m, n \le 65535$).

### 2.3 Multi-Stage 8D Euclidean Residual Vector Quantization

Let $\widetilde{W}_{\text{bulk}}$ be $W_{\text{rot}}$ with outlier positions $\Omega$ zeroed out, reshaped into $N_v = (m \cdot n) / 8$ vectors in $\mathbb{R}^8$. For a configuration with $S$ stages and codebook size $K \in \{32, 64, 128, 256\}$ (requiring $b = \lceil \log_2 K \rceil$ bits per stage index), we sample up to $32,768$ vectors and train $S$ cascaded codebooks $\{C^{(1)}, \dots, C^{(S)}\}$ via 8 iterations of batched Euclidean $k$-means per stage:

$$a_t = \arg\min_{k \in \{1,\dots,K\}} \|r^{(t)} - C^{(t)}_k\|_2^2, \qquad r^{(t+1)} = r^{(t)} - \operatorname{fp16}\!\left(C^{(t)}_{a_t}\right)$$

Stage codebooks are stored in `float16` ($K \times 8 \times 2$ bytes per stage), and stage indices are tightly bit-packed into `uint8` arrays of $\lceil N_v \cdot b / 8 \rceil$ bytes per stage.

### 2.4 Block-8 Cholesky GPTQ Error Propagation

Columns are partitioned into $n_b = n / 8$ blocks of width $B = 8$, $J_t = \{8t, \dots, 8t+7\}$. Rather than inverting $8 \times 8$ blocks inside the loop, we pre-invert all $n_b$ diagonal $8 \times 8$ blocks of $U$ in a single batched `torch.linalg.inv` call:

$$D_t = \left(U_{J_t, J_t}\right)^{-1} \in \mathbb{R}^{8 \times 8}$$

At block step $t = 0, \dots, n_b - 1$:
1. Extract current block $W_{\text{cur}}[:, J_t]$ and zero out positions belonging to $\Omega_{:, J_t}$.
2. Quantize the non-outlier vectors via the $S$-stage RVQ codebooks: $Q_{\text{rvq}} = \sum_{s=1}^S C^{(s)}_{a_s}$.
3. Restore protected salient outliers in `float16`: $Q[:, J_t] = Q_{\text{rvq}}$ on $\Omega^c_{:, J_t}$ and $\operatorname{fp16}(W_{\text{cur}}[:, J_t])$ on $\Omega_{:, J_t}$.
4. Propagate the block quantization residual to all remaining columns $R_t = \{8t+8, \dots, n-1\}$:

$$E_{J_t} = \left(W_{\text{cur}}[:, J_t] - Q[:, J_t]\right) D_t, \qquad W_{\text{cur}}[:, R_t] \leftarrow W_{\text{cur}}[:, R_t] - E_{J_t} \, U_{J_t, R_t}$$

Finally, the inverse Block-Hadamard transform maps the quantized representation back to the original weight space:

$$\widehat{W} = \operatorname{reshape}_{m \times n}\!\left(\operatorname{reshape}_{m \times (n/g) \times g}(Q) \cdot R_g^T\right)$$

### 2.5 Exact Bitrate Accounting

For an $m \times n$ matrix ($N_v = mn/8$ vectors) with $S$ stages, codebook size $K$ ($b = \lceil \log_2 K \rceil$ index bits), and $N_{\text{out}}$ outliers:

$$\text{Bytes} = S \left(16 K + \left\lceil \frac{N_v b}{8} \right\rceil\right) + 6 N_{\text{out}} + 12, \qquad \text{BPW} = \frac{8 \cdot \text{Bytes}}{mn}$$

---

## 3. Empirical Results and Pareto Frontier

All single-model benchmarks below were measured on **Qwen2.5-Coder-1.5B** (`28` transformer layers, `lm_head` unquantized) using `32,768` calibration tokens and `98,304` held-out evaluation tokens on an 8 GB RTX 5060 GPU.

### 3.1 Non-Hessian Baselines vs. Scalar GPTQ (`results_m3_proof.json`)

- **BF16 Baseline:** $\text{PPL} = 5.3418$ (`5.341823717756528`)
- **Peak VRAM:** `8.729 GiB` | **Total Sweep Time:** `1394.7 s`

| Method | Effective BPW | Mean Rel L2 | Mean Cosine | Eval PPL | Ratio vs BF16 | Runtime (s) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Pure M3 (3-stage, 8b idx, int32 out) | 3.8141 | 0.19684 | 0.98059 | 6.8641 | 1.2850x | 55.0 |
| Pure M3 (2-stage, 8b idx, int32 out) | 2.8092 | 0.32494 | 0.94593 | 21.3112 | 3.9895x | 75.8 |
| M3+ (Hadamard + 3-stage 8b + uint16 out) | 3.2536 | 0.19286 | 0.98128 | 6.5363 | 1.2236x | 94.2 |
| M3+ Compact (Hadamard + 3-stage 4b + uint16 out) | 1.7398 | 0.46914 | 0.88314 | 92182.0901 | 17256.6702x | 44.0 |
| GPTQ + Hadamard (4-bit) | 4.1250 | 0.14097 | 0.99018 | 5.4383 | 1.0181x | 383.3 |
| GPTQ + Hadamard (3-bit) | 3.1250 | 0.30369 | 0.95681 | 5.9150 | 1.1073x | 666.6 |

### 3.2 M3-GPTQ Pareto Frontier (`results_m3_gptq.json`)

- **BF16 Baseline:** $\text{PPL} = 5.3418$ (`5.341823711116762`)
- **Peak VRAM:** `5.782 GiB`

| Method | Effective BPW | Mean Rel L2 | Mean Cosine | Eval PPL | Ratio vs BF16 | Runtime (s) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| M3-GPTQ (Hadamard + OBQ 0.5% + 3x8b) | 3.2534 | 0.25096 | 0.96789 | **5.7666** | **1.0795x** | 649.1 |
| M3-GPTQ Tight (Hadamard + OBQ 0.25% + 3x8b) | 3.1339 | 0.25779 | 0.96609 | **5.8038** | **1.0865x** | 449.2 |
| M3-GPTQ 3x7b (Hadamard + OBQ 0.25% + 3x7b) | 2.7515 | 0.32173 | 0.94682 | **6.2202** | **1.1644x** | 458.7 |
| M3-GPTQ 4x5b (Hadamard + OBQ 0.25% + 4x5b) | 2.6217 | 0.36894 | 0.92950 | **6.7483** | **1.2633x** | 539.9 |
| M3-GPTQ 3x6b (Hadamard + OBQ 0.25% + 3x6b) | 2.3729 | 0.39942 | 0.91717 | **7.3194** | **1.3702x** | 518.2 |
| M3-GPTQ 2x8b (Hadamard + OBQ 0.25% + 2x8b) | 2.1291 | 0.42802 | 0.90502 | **8.2920** | **1.5523x** | 364.6 |

### 3.3 Key Findings from the Pareto Sweep

1. **Hessian Feedback Solves the Vector Quantization Gap:** At **3.2534 bpw**, M3-GPTQ (`3x8b`, 0.5% OBQ) drops perplexity from **6.5363** (`M3+`, 3.2536 bpw) to **5.7666**—an improvement of **0.7697 PPL** at identical storage cost.
2. **M3-GPTQ Outperforms Scalar 3-Bit GPTQ:** At **3.1339 bpw**, `M3-GPTQ Tight` achieves **5.8038 PPL** (cosine **0.96609**) compared to **5.9150 PPL** (cosine **0.95681**) for `GPTQ + Hadamard (3-bit)` at `3.1250 bpw`.
3. **Sub-3-Bit Stability & Codebook Efficiency:** `3x7b` (**2.7515 bpw**, **6.2202 PPL**) provides a strong compression/quality sweet spot, outperforming `4x5b` (**2.6217 bpw**, **6.7483 PPL**) because 3 stages of 128-entry codebooks capture residual structure more effectively than 4 coarser 32-entry stages at similar total bits. Below 2.5 bpw, `3x6b` (**2.3729 bpw**, **7.3194 PPL**) and `2x8b` (**2.1291 bpw**, **8.2920 PPL**) remain completely stable, whereas non-Hessian `Pure M3 (2-stage)` at higher bitrate (`2.8092 bpw`) degraded to `21.3112 PPL`.
4. **Memory Efficiency:** Layer-by-layer Hessian accumulation and tensor-reshaped Hadamard transforms reduce peak VRAM from `8.729 GiB` (`results_m3_proof.json`) to **5.782 GiB** (`results_m3_gptq.json`).

---

## 4. End-to-End 28-Layer Pipeline Verification (`Merge -> Gauge Rotation -> M3-GPTQ 3x7b`)

To verify composability with model merging and basis transmutation, the 28-layer pipeline in `results_e2e_pipeline_proof.json` was executed sequentially on `65,536` held-out evaluation tokens (`peak_vram_gib = 6.424 GiB`, `total_seconds = 470.5 s`):

| Pipeline Stage | Effective BPW | Mean Cosine | Mean Rel L2 | Eval PPL | Drift / Ratio | Time (s) |
| :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| Stage 1: 28L Anchored Contextual Merge (BF16) | 16.0000 | — | — | **4.9813** | Baseline | 49.1 |
| Stage 2: 28L RoPE-Safe Orthogonal Gauge Rotation | 16.0000 | — | — | **4.9878** | `+0.0065` drift | 1.2 |
| Stage 3: **M3-GPTQ (`3x7b`, 0.25% OBQ)** | **2.7517** | **0.94919** | **0.31475** | **5.8726** | **1.1789x** vs Stage 1 | 345.3 |

This confirms that RoPE-safe orthogonal gauge rotation introduces near-zero perplexity drift (`+0.0065`) and composes cleanly with downstream `M3-GPTQ 3x7b` compression at `2.7517` bpw.

---

## 5. Cross-Model & Cross-Method Benchmarks (`WikiText-2`, `MMLU-100`, `ARC-100`)

To validate generalization across architectures and model scales (`1.5B` to `15.55B`), we evaluated **ZAQERIS M3-GPTQ (`3x8b`, `normalize_rows=True`)** on a single consumer **NVIDIA GeForce RTX 5060 Laptop GPU (8 GB VRAM, ~6.87 GiB Windows WDDM CUDA budget)** against **Uncompressed BF16**, **BitsAndBytes NF4 (`4.25 bpw`)**, and matched-bitrate **GPTQ Scalar 3-bit (`g=128`, `3.25 bpw`)** using `Salesforce/wikitext` (`wikitext-2-raw-v1`, `32,768` calibration tokens, `32,768` test tokens, `seq_len=1024`), `MMLU (100)`, and `ARC-Challenge (100)`.

### 5.1 Cross-Model Summary (`~3.25 bpw` M3-GPTQ vs Matched 3-bit Scalar GPTQ & 4-bit NF4)

| Model | Method | Linear BPW | Disk / Loaded VRAM | WikiText-2 PPL (Ratio) | MMLU (100) | ARC (100) | Mean Cosine |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: | :---: |
| **Qwen2.5-Coder-1.5B** | BF16 Baseline | `16.0000` | `2.875 GiB` | `14.5730` (`1.0000x`) | `43%` | `65%` | `1.00000` |
| (`28L, d=1536, inter=8960`) | BitsAndBytes NF4 | `4.2500` | `1.074 GiB` VRAM | `15.2822` (`1.0487x`) | `45%` | `58%` | — |
| | **M3-GPTQ 3x8b (`norm_rows`)** | **`3.2606`** | `0.932` / `0.948 GiB` | **`16.3073`** (`1.1190x`) | **`46%`** | **`50%`** | **`0.97120`** |
| | M3-GPTQ 3x7b (`norm_rows`) | `2.7590` | `0.856` / `0.866 GiB` | `17.6485` (`1.2110x`) | `35%` | `50%` | `0.95292` |
| | GPTQ Scalar 3-bit (`g=128`) | `3.2500` | `2.241 GiB` Peak | `18.9955` (`1.3035x`) | `29%` | `38%` | `0.95563` |
| **Qwen2.5-Coder-7B-Instruct** | BF16 Baseline | `16.0000` | `14.185 GiB` | `10.3723` (`1.0000x`) | `60%` | `80%` | `1.00000` |
| (`28L, d=3584, inter=18944`) | BitsAndBytes NF4 | `4.2500` | `6.173 GiB` VRAM | `10.6859` (`1.0302x`) | `62%` | `82%` | — |
| | **M3-GPTQ 3x8b (`norm_rows`)** | **`3.2455`** | `4.496` / `4.540 GiB` | **`11.2262`** (`1.0823x`) | **`55%`** | `76%` | **`0.96776`** |
| | GPTQ Scalar 3-bit (`g=128`) | `3.2500` | `7.078 GiB` Peak | `11.4856` (`1.1073x`) | `51%` | `78%` | `0.94972` |
| **Mistral-7B-Instruct-v0.3** | BF16 Baseline | `16.0000` | `13.500 GiB` | `6.2501` (`1.0000x`) | `57%` | `81%` | `1.00000` |
| (`32L, d=4096, inter=14336`) | BitsAndBytes NF4 | `4.2500` | `4.820 GiB` VRAM | `6.4665` (`1.0346x`) | `52%` | `75%` | — |
| | **M3-GPTQ 3x8b (`norm_rows`)** | **`3.2452`** | `3.137` / `3.253 GiB` | **`6.6461`** (`1.0634x`) | `50%` | `62%` | **`0.97163`** |
| | GPTQ Scalar 3-bit (`g=128`) | `3.2500` | `5.118 GiB` Peak | `7.0901` (`1.1344x`) | `50%` | `66%` | `0.96028` |
| **ZAQERIS/ZQN-12B** | BF16 (Stage-4 SFT v4) | `16.0000` | `28.900 GiB` | `8.5696` (`1.0000x`) | `73%` | `88%` | — |
| (`48L, d=5120, 15.55B params`) | **M3-GPTQ 3x8b (`norm_rows`)** | **`3.2484`** | `6.479` / **`6.046 GiB`** | **`10.9036`** (`1.2724x`) | `61%` | **`88%`** | — |

### 5.2 Key Cross-Model Findings, Novelty & Limitations

1. **Novel Contribution:** Rather than proposing a new standalone vector quantizer or scalar GPTQ variant in isolation, our contribution is the **unified composition** of memory-lean `Block-Hadamard (g=128)` decorrelation, `OBQ` Hessian-salience outlier protection, bit-packed multi-stage `8D RVQ`, and `Block-8 Cholesky GPTQ` error propagation—demonstrating empirically that this combination cures the non-Hessian RVQ collapse below `3.5 bpw`.
2. **Consistent Superiority over Matched 3-Bit Scalar GPTQ (`~3.25 bpw`):** Across all three matched comparisons (`Qwen2.5-Coder-1.5B`, `Qwen2.5-Coder-7B-Instruct`, and `Mistral-7B-Instruct-v0.3`), `M3-GPTQ 3x8b` outperforms `GPTQ Scalar 3-bit` in both WikiText-2 perplexity and weight cosine similarity—cutting the BF16 perplexity gap on Mistral-7B-v0.3 by more than half (`+6.34%` vs `+13.44%`).
3. **8 GB VRAM Deployment Advantage for 12B–15B Models:** While 4-bit `NF4` (`4.25 bpw`) remains more accurate when a model comfortably fits in VRAM (1.5B and 7B), a `15.55B` model such as `ZQN-12B` requires `~8.8 GiB` for weights alone in 4-bit NF4 (exceeding the `~6.87 GiB` Windows WDDM physical CUDA budget before activations). `M3-GPTQ` compresses `ZQN-12B` to `6.479 GiB` on disk and `6.046 GiB` **loaded weight VRAM**, with an **eval peak VRAM of `7.522 GiB`** (spilling ~`0.65 GiB` to shared WDDM system memory only at peak `seq_len=1024` activations) while retaining `88%` ARC accuracy (`100%` of BF16).
4. **Runtime Separation & Limitations (Explicit Disclosure):**
   - **Decode Throughput:** The `22.94 tok/s` decode speed reported for `ZQN-12B` is achieved exclusively by a **model-specific custom `NVRTC LUT + Static CUDA Graph` kernel** (`06_Code_and_Benchmarks/nvrtc_kernel_reference/modeling_zaqeris_zaqion_12b.py`). The general public `M3Linear` reference module in `zaqeris_m3_gptq/runtime.py` dequantizes weights in PyTorch and achieves **`0.19–1.53 tok/s`**. `22.94 tok/s` must **not** be attributed to the general `zaqeris-m3-gptq v0.1.0` package until the fused NVRTC kernel is integrated in `v0.2`.
   - **Fake-Quant GPTQ Scalar Baseline:** `GPTQ Scalar 3/4-bit` baselines in Section 5 use BF16 dequantized fake-quant weights for apples-to-apples PPL/MMLU/ARC fidelity measurement and are therefore not comparable for decode `tok/s` or packed VRAM.
   - **Calibration & Compression Overhead:** Unlike data-free round-to-nearest `NF4`, `M3-GPTQ` requires `32,768` calibration tokens and Hessian Cholesky inversion (`2,164 s` on Mistral-7B; `6,375 s` on Qwen-7B `18,944`-dim layers under WDDM VRAM pressure).
   - **Evaluation Scope:** `MMLU (100)` and `ARC (100)` are 100-question subsets rather than full 14K MMLU or HumanEval-164.

---

## 6. Self-Contained Reproducibility Package (`Weights & Datasets Not Bundled`)

All source code, unit/integration tests, NVRTC kernel reference, benchmark scripts, Apache-2.0 `LICENSE`, and raw JSON logs referenced in this paper are included inside this archive. **Model weights and evaluation datasets are intentionally not bundled**; any researcher can download them directly from Hugging Face (`Qwen/Qwen2.5-Coder-1.5B`, `Qwen/Qwen2.5-Coder-7B-Instruct`, `mistralai/Mistral-7B-Instruct-v0.3`, `ZAQERIS/ZQN-12B`, `Salesforce/wikitext`, `cais/mmlu`, `allenai/ai2_arc`) and reproduce all runs locally:
- **Package Source, License & Tests (`36/36 pytest`):** `06_Code_and_Benchmarks/zaqeris-m3-gptq/` (`zaqeris_m3_gptq/`, `tests/test_m3_public.py`, `pyproject.toml`, `LICENSE`)
- **Custom NVRTC CUDA Graph Reference (`ZQN-12B`):** `06_Code_and_Benchmarks/nvrtc_kernel_reference/modeling_zaqeris_zaqion_12b.py`
- **Pipeline Reference (`Merge -> Gauge Rotation -> M3-GPTQ`):** `06_Code_and_Benchmarks/exp_e2e_pipeline_proof.py` (requires local merge checkpoints and corpus)
- **Raw JSON Logs:** `01_Results/` (`results_m3_proof.json`, `results_m3_gptq.json`, `results_e2e_pipeline_proof.json`, `qwen2.5_coder_1.5b_full_comparison.json`, `qwen2.5_coder_7b_comparison.json`, `mistral_7b_comparison.json`, `zqn12b_paired_comparison.json`)

```bash
cd 06_Code_and_Benchmarks/zaqeris-m3-gptq
pip install -e ".[dev,benchmarks]"
pytest -v
python ../run_quant_comparison.py \
  --model mistralai/Mistral-7B-Instruct-v0.3 \
  --fast --calib-tokens 32768 --eval-tokens 32768 \
  --output-json ../../01_Results/mistral_7b_reproduced.json
```
