# ZAQERIS M3-GPTQ — Press Kit, Factsheet & Ready-to-Post Announcements

> **القاعدة التحريرية:** جميع الأرقام المذكورة في هذا الملف مستخرجة مباشرة من القياسات المحلية الموثقة في [`01_Results/`](../01_Results/) و[`02_FINAL_RESULTS_AND_CONFIGS_REPORT.md`](../04_Reports_and_Reviews/02_FINAL_RESULTS_AND_CONFIGS_REPORT.md) دون أي تضخيم أو أرقام غير مقاسة.

---

## 1. بطاقة الحقائق السريعة (`Verified Factsheet`)

- **اسم التقنية:** ZAQERIS M3-GPTQ (`Multi-Stage 8D Residual Vector Quantization + Block-8 Cholesky GPTQ + OBQ Salience + Block-Hadamard`)
- **الحزمة مفتوحة المصدر:** `zaqeris-m3-gptq v0.1.0` (`36 / 36` اختبار `pytest` ناجح)
- **العتاد المرجعي للاختبارات:** بطاقة واحدة `NVIDIA GeForce RTX 5060 Laptop GPU (8 GB VRAM)`
- **أهم النتائج المثبتة عند `~3.25 bpw` (مقارنةً بـ `GPTQ Scalar 3-bit` على `WikiText-2`، `32K` رمز):**
  - **`Mistral-7B-Instruct-v0.3` (`13.5 GiB -> 3.137 GiB`):** `PPL = 6.6461` (`1.0634x` أمام BF16 `6.2501`) مقابل `7.0901` (`1.1344x`) لـ `GPTQ Scalar 3-bit` — تقليص فجوة الحيرة اللغوية بأكثر من **النصف**!
  - **`Qwen2.5-Coder-7B-Instruct` (`14.185 GiB -> 4.496 GiB`):** `PPL = 11.2262` (`1.0823x` أمام BF16 `10.3723`)، `MMLU = 55%`، مقابل `11.4856` (`1.1073x`) و`MMLU = 51%` لـ `GPTQ Scalar 3-bit`.
  - **`Qwen2.5-Coder-1.5B` (`2.875 GiB -> 0.932 GiB`):** `PPL = 16.3073` (`MMLU 46%`, `ARC 50%`) مقابل `18.9955` (`MMLU 29%`, `ARC 38%`) لـ `GPTQ Scalar 3-bit`؛ وحتى نسخة `3x7b` (`2.759 bpw`) تفوقت على `GPTQ 3-bit` (`17.6485 PPL`).
  - **`ZAQERIS/ZQN-12B` (`15.55B` معامل / `28.9 GiB -> 6.479 GiB`):** أوزان النموذج المحمّلة (`Loaded VRAM`) تبلغ **`6.046 GiB`** بينما تصل **ذروة التقييم (`Eval Peak VRAM`) إلى `7.522 GiB`** (مقابل `~8.8 GiB` لأوزان `4-bit NF4` وحدها قبل التنشيطات)، مع احتفاظ كامل بدقة **`ARC = 88%`**؛ ويسجل **`22.94 tok/s`** عبر **كيرنل `NVRTC LUT + Static CUDA Graph` المخصص لـ `ZQN-12B`**.
- **الشفافية الهندسية (فصل مسارات السرعة والذاكرة):** عند توفر مساحة `4.25 bpw` لـ `1.5B` و`7B`، يظل `BitsAndBytes NF4` أدق قليلاً؛ وتعمل الحزمة العامة `M3Linear` حالياً بمسار PyTorch المرجعي (**`0.19–1.53 tok/s`**)، ولا يجوز نسب سرعة `22.94 tok/s` إلى الحزمة العامة قبل دمجه في `v0.2`، كما لا يجوز تقديم `6.046 GiB` كذروة استخدام.
- **النماذج والبيانات:** غير مضمّنة في الأرشيف؛ يمكن لأي مطور تحميلها مباشرة من Hugging Face وتشغيل الاختبارات محلياً.

---

## 2. منشور X (Twitter) — مسار ثريد جاهز للنشر (عربي / English)

### النسخة العربية (Thread)
> **1/5:** كيف تشغّل نموذج `15.55B` بحجم `28.9 GiB` على كرت لابتوب `8 GB VRAM` وبنفس دقة `ARC = 88%`؟  
> نشارك اليوم النتائج الكاملة لتقنية الضغط مفتوحة المصدر **ZAQERIS M3-GPTQ** بعد اختبارها عبر 4 نماذج (`1.5B` إلى `15.55B`) ومقارنتها مع `GPTQ 3-bit` و`NF4`. 🧵👇
>
> **2/5:** المشكلة في التكميم المتجهي وحده (`RVQ`) تحت `3.5 bpw` أنه يحقق تشابه أوزان عالياً لكنه ينهار في الحيرة اللغوية (`PPL`).  
> في **M3-GPTQ** جمعنا 4 آليات: `Block-Hadamard (g=128)` + انتقاء الشواذ بأهمية `OBQ Hessian` + `8D RVQ` متعدد المراحل + تعويض أخطاء `Block-8 Cholesky GPTQ`.
>
> **3/5:** النتيجة عند نفس معدل البت (`~3.25 bpw`) أمام `GPTQ Scalar 3-bit` على `WikiText-2`:  
> • **Mistral-7B-v0.3** (`3.14 GiB` فقط!): `6.65` مقابل `7.09 PPL` (نصف فجوة التدهور أمام BF16!)  
> • **Qwen2.5-Coder-7B** (`4.50 GiB`): `11.23` مقابل `11.49 PPL` و`MMLU 55%` مقابل `51%`  
> • **Qwen2.5-Coder-1.5B**: `16.31` مقابل `19.00 PPL` و`MMLU 46%` مقابل `29%`
>
> **4/5:** ومتى يصنع الفارق الحقيقي في السعة؟  
> على `ZQN-12B` (`15.55B` معامل): حزمة `4-bit NF4` (`~8.8 GiB`) لا تسع بطاقة `8 GB` على ويندوز، بينما `M3-GPTQ` ضغطته إلى **`6.48 GiB`** (`6.05 GiB VRAM`) مع **`ARC = 88%`** (مطابق لـ BF16) — ومع كيرنل `NVRTC CUDA Graph` المخصص لـ `ZQN-12B` وصل إلى **`22.94 tok/s`**!
>
> **5/5:** نلتزم بالشفافية العلمية الكاملة: الحزمة العامة `M3Linear` تعمل حالياً بمسار PyTorch (`0.19–1.53 tok/s`) ودمج كيرنل `NVRTC` السريع بها هو هدف `v0.2`، كما يظل `NF4` أدق قليلاً عند `4.25 bpw`.  
> الأرشيف الكامل (`zaqeris_m3_gptq` + `36/36` اختبار + كود `NVRTC` + النتائج الخام) جاهز لإعادة الإنتاج.

### English Version (Thread)
> **1/4:** Can you fit a **15.55B** parameter LLM (`28.9 GiB BF16`) inside an **8 GB laptop GPU** while preserving **88% ARC-Challenge** accuracy?  
> Today we are releasing the full cross-model benchmark & technical paper for **ZAQERIS M3-GPTQ** (`zaqeris-m3-gptq`). 🧵👇
>
> **2/4:** Pure vector quantization (`RVQ`) without second-order curvature awareness suffers severe perplexity collapse below 3.5 bpw. **M3-GPTQ** combines memory-lean `Block-Hadamard (g=128)`, `OBQ Hessian` outlier salience, multi-stage `8D RVQ`, and `Block-8 Cholesky GPTQ` error propagation.
>
> **3/4:** Head-to-head at **~3.25 bpw** vs **GPTQ Scalar 3-bit (g=128)** on `WikiText-2` (32K test tokens, RTX 5060 8 GB):  
> • **Mistral-7B-v0.3** (`13.5 -> 3.137 GiB`): **6.6461** (`1.0634x` BF16) vs **7.0901** (`1.1344x`)  
> • **Qwen2.5-Coder-7B** (`14.19 -> 4.496 GiB`): **11.2262** (MMLU 55%) vs **11.4856** (MMLU 51%)  
> • **Qwen2.5-Coder-1.5B** (`2.88 -> 0.932 GiB`): **16.3073** (MMLU 46%) vs **18.9955** (MMLU 29%)
>
> **4/4:** On **ZQN-12B (15.55B)**, 4-bit NF4 (~8.8 GiB) overflows an 8 GB Windows CUDA budget, whereas M3-GPTQ fits at **6.479 GiB disk / 6.046 GiB VRAM**, keeping **88% ARC** (100% of BF16) and reaching **22.94 tok/s** using ZQN-12B's custom NVRTC CUDA Graph kernel (note: the general `M3Linear` PyTorch runtime runs at `0.19–1.53 tok/s` until NVRTC integration in v0.2). Full source, `36/36` tests, and raw JSONs included!

---

## 3. منشور LinkedIn الاحترافي (جاهز للنسخ)

> **إطلاق النتائج الكاملة وحزمة إعادة الإنتاج لتقنية الضغط ZAQERIS M3-GPTQ**
>
> تشغيل النماذج اللغوية الكبيرة محلياً على بطاقات اقتصادية (`8 GB VRAM`) يصطدم عادةً بمعضلة قاسية عند النزول تحت 3.5 بت لكل معامل: إما انهيار الجودة في التكميم المتجهي التقليدي، أو خشونة التدرج في التكميم العددي `3-bit GPTQ`.
>
> اختبرنا **ZAQERIS M3-GPTQ** (`8D RVQ` موجّه بـ `OBQ Hessian` + `Block-Hadamard` + `Block-8 Cholesky GPTQ`) محلياً على بطاقة `RTX 5060 8 GB` عبر **4 نماذج مختلفة**:
> 1. **`Mistral-7B-Instruct-v0.3`**: انخفض الحجم من `13.5 GiB` إلى **`3.137 GiB`** بمعدل حيرة لغوية `6.6461 PPL` (`+6.34%` فقط أمام BF16)، متفوقاً بوضوح على `GPTQ 3-bit` (`7.0901 PPL`).
> 2. **`Qwen2.5-Coder-7B-Instruct`**: انخفض الحجم إلى **`4.496 GiB`** مع تفوق على `GPTQ 3-bit` في الحيرة اللغوية (`11.23` مقابل `11.49`) وفي `MMLU` (`55%` مقابل `51%`).
> 3. **`Qwen2.5-Coder-1.5B`**: تفوق حتى بضغط `2.76 bpw` (`3x7b`) على `GPTQ 3-bit` (`3.25 bpw`).
> 4. **`ZAQERIS/ZQN-12B` (`15.55B`)**: تقلص من `28.9 GiB` إلى **`6.479 GiB`** ليصبح قابلاً للتشغيل بالكامل على بطاقة `8 GB` بدقة `ARC = 88%`، وسرعة `22.94 tok/s` عبر كيرنل `NVRTC CUDA Graph` المخصص لهذا النموذج (بينما تعمل الحزمة العامة `M3Linear` حالياً بمسار PyTorch المرجعي `0.19–1.53 tok/s`).
>
> أرفقنا في الحزمة تدقيقاً نقدياً داخلياً يبرز نقاط القوة والقيود بشفافية (منها أسبقية `NF4` في الـ `4-bit` حين تتسع الذاكرة، وخارطة طريق دمج كيرنل `NVRTC LUT` في الحزمة العامة).

---

## 4. الأسئلة الشائعة (`Press & Community FAQ`)

- **س: هل `M3-GPTQ` أفضل دائماً من `BitsAndBytes NF4`؟**  
  **ج:** لا. `NF4` يعمل عند `4.25 bpw`، لذا إذا كان النموذج يتسع في ذاكرتك بـ 4 بت (مثل 7B على 8 GB)، فإن `NF4` يعطي حيرة لغوية أدق قليلاً (`10.69` مقابل `11.23` على Qwen-7B) بدون معايرة مسبقة. ميزة `M3-GPTQ` الحاسمة هي عند **`~3.25 bpw` فأقل** (يتفوق على `GPTQ 3-bit`) وعند ضغط نماذج **`12B–15B`** لتتسع داخل `8 GB VRAM` بدلاً من نفاد الذاكرة.
- **س: لماذا تختلف سرعة التوليد بين `ZQN-12B` (`22.94 tok/s`) و`Qwen-7B` (`0.22 tok/s`) في ملفات الاختبار؟**  
  **ج:** `ZQN-12B` يستخدم كيرنل `NVRTC LUT + CUDA Graph` المدمج الذي يحسب الضرب مباشرة من جداول البحث دون فك ضغط المصفوفة كاملة، بينما `M3Linear` العام في `zaqeris-m3-gptq v0.1.0` يستخدم مسار PyTorch مرجعي يفك الضغط لكل طبقة، ونقل الكيرنل السريع إليه هو هدف `v0.2`.
